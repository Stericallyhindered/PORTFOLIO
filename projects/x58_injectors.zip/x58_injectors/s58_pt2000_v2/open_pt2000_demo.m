function open_pt2000_demo()
%OPEN_PT2000_DEMO Build if needed, then open the top level and dashboard.
root=fileparts(mfilename('fullpath')); addpath(genpath(root));
model='pt2000_dual_injector_demo'; file=fullfile(root,model+'.slx');
if ~isfile(file), build_pt2000_v2_model(); else, load_system(file); end
set_param(model,'StopTime','inf');
open_system(model); set_param(model,'ZoomFactor','FitSystem');
open_system(model+'/Operator Dashboard');
set_param(model+'/Operator Dashboard','ZoomFactor','FitSystem');
fprintf('PT2000 V2 ready. Press Run; dashboard commands remain tunable while running.\n');
end
