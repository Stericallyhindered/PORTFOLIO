function tests = test_network_contract
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root, 'config'), fullfile(root, 'network'));
testCase.TestData.root = root;
end

function testDatabaseAndFdLengths(testCase)
db = canDatabase(fullfile(testCase.TestData.root, 'network', 'pt2000_demo.dbc'));
verifyEqual(testCase, numel(db.MessageInfo), 9);
lengths = [db.MessageInfo.Length];
verifyEqual(testCase, nnz(lengths == 16), 8);
verifyEqual(testCase, nnz(lengths == 8), 1);
for index = find(lengths == 16)
    message = canFDMessage(db.MessageInfo(index).ID, false, 16);
    verifyEqual(testCase, message.DLC, uint8(10));
end
end

function testCrcKnownCheckAndBitFlip(testCase)
payload = uint8(0:14);
crc = crc8_sae_j1850(payload);
frame = [payload crc];
[valid, reason, next] = validate_e2e_frame(frame, uint8(14));
verifyTrue(testCase, valid);
verifyEqual(testCase, reason, "OK");
verifyEqual(testCase, next, uint8(15));
frame(5) = bitxor(frame(5), uint8(4));
[valid, reason] = validate_e2e_frame(frame, uint8(14));
verifyFalse(testCase, valid);
verifyEqual(testCase, reason, "CRC");
end

function testCounterRejection(testCase)
frame = zeros(1,16,'uint8');
frame(15) = 7;
frame(16) = crc8_sae_j1850(frame(1:15));
[valid, reason] = validate_e2e_frame(frame, uint8(6));
verifyFalse(testCase, valid);
verifyEqual(testCase, reason, "COUNTER");
end

function testLoadBudget(testCase)
report = analyze_can_fd_load();
verifyTrue(testCase, report.passes);
verifyLessThanOrEqual(testCase, report.totalUtilizationPct, report.limitPct);
end

function testDatabaseSignalPacking(testCase)
db = canDatabase(fullfile(testCase.TestData.root, 'network', 'pt2000_demo.dbc'));
message = canFDMessage(db,'ENGINE_STATE');
message.Signals.EngineSpeed = 5250.25;
message.Signals.EngineLoad = 87.35;
message.Signals.BatteryVoltage = 13.742;
verifyEqual(testCase,message.ProtocolMode,'CAN FD');
verifyTrue(testCase,message.BRS);
verifyEqual(testCase,message.Signals.EngineSpeed,5250.25,'AbsTol',0.25);
verifyEqual(testCase,message.Signals.EngineLoad,87.35,'AbsTol',0.01);
verifyEqual(testCase,message.Signals.BatteryVoltage,13.742,'AbsTol',0.001);
end

function testCommandTimeout(testCase)
[valid,fault]=validate_command_age(14.999,15); verifyTrue(testCase,valid); verifyEqual(testCase,fault,uint16(0));
[valid,fault]=validate_command_age(15.001,15); verifyFalse(testCase,valid); verifyEqual(testCase,fault,uint16(1));
[valid,fault]=validate_command_age(NaN,15); verifyFalse(testCase,valid); verifyEqual(testCase,fault,uint16(1));
end
