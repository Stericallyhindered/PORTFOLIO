function tests = test_pt2000_spi_protocol
tests=functiontests(localfunctions);
end

function setupOnce(testCase)
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'config'),fullfile(root,'pt2000'));
testCase.TestData.cfg=pt2000_system_config();
end

function testRequiredSpiMode(testCase)
verifyEqual(testCase,testCase.TestData.cfg.spi.cpol,0);
verifyEqual(testCase,testCase.TestData.cfg.spi.cpha,1);
verifyEqual(testCase,testCase.TestData.cfg.spi.mode,1);
verifyEqual(testCase,testCase.TestData.cfg.spi.wordBits,16);
end

function testControlWordLayout(testCase)
word=pt2000_spi_control_word(true,hex2dec('155'),7);
verifyEqual(testCase,bitget(word,16),uint16(1));
verifyEqual(testCase,bitand(bitshift(word,-5),uint16(1023)),uint16(hex2dec('155')));
verifyEqual(testCase,bitand(word,uint16(31)),uint16(7));
end

function testBurstWriteRead(testCase)
memory=zeros(1024,1,'uint16'); data=uint16([hex2dec('1234') hex2dec('ABCD') 77]);
[memory,~,status]=pt2000_spi_transaction(memory,pt2000_spi_control_word(false,100,3),data);
verifyEqual(testCase,status,uint16(0));
[~,readback,status]=pt2000_spi_transaction(memory,pt2000_spi_control_word(true,100,3));
verifyEqual(testCase,status,uint16(0)); verifyEqual(testCase,readback,data);
end

function testBurstBoundaryFault(testCase)
memory=zeros(1024,1,'uint16');
[~,~,status]=pt2000_spi_transaction(memory,pt2000_spi_control_word(true,1020,8));
verifyEqual(testCase,bitand(status,uint16(1)),uint16(1));
end
