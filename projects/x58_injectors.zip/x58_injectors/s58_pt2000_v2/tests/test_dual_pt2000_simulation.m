function tests = test_dual_pt2000_simulation
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root,'config'), fullfile(root,'simulation'));
testCase.TestData.root = root;
end

function testNominalDualInjection(testCase)
result = simulate_dual_pt2000(struct('durationS',0.014));
verifyEqual(testCase, height(result.summary), 2);
verifyGreaterThan(testCase, min(result.summary.PeakCurrent_A), 3.0);
verifyGreaterThan(testCase, min(result.summary.DeliveredMass_mg), 0.1);
verifyGreaterThan(testCase, min(result.summary.PeakLift_um), 1.0);
verifyEqual(testCase, result.summary.FaultBits, zeros(2,1,'uint16'));
verifyFalse(testCase, result.meta.releaseApproved);
end

function testOpenCircuitDiagnostic(testCase)
scenario = struct('durationS',0.012,'openCircuitChannel',1);
result = simulate_dual_pt2000(scenario);
verifyLessThan(testCase, result.summary.PeakCurrent_A(1), 0.01);
verifyEqual(testCase, bitand(result.summary.FaultBits(1),uint16(1)),uint16(1));
verifyGreaterThan(testCase, result.summary.PeakCurrent_A(2), 3.0);
end

function testShortCircuitProtection(testCase)
scenario = struct('durationS',0.008,'shortCircuitChannel',2);
result = simulate_dual_pt2000(scenario);
verifyEqual(testCase, bitand(result.summary.FaultBits(2),uint16(2)),uint16(2));
verifyEqual(testCase, bitand(result.summary.FaultBits(2),uint16(4)),uint16(4));
verifyLessThanOrEqual(testCase, max(result.timeseries.Current2_A), 21.6);
end

function testScheduleRespondsToLoadAndBoost(testCase)
cfg = pt2000_system_config();
low = schedule_fuel_command(2500,30,2,1.0,cfg);
high = schedule_fuel_command(5500,100,28,0.78,cfg);
verifyGreaterThan(testCase, high.fuelMassMg, low.fuelMassMg);
verifyGreaterThan(testCase, high.pulseWidthUs, low.pulseWidthUs);
end
