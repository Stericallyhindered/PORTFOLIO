function run_pt2000_fast_demo()
%RUN_PT2000_FAST_DEMO Launch the interactive demo with lightweight logging.
root = fileparts(mfilename('fullpath'));
cd(root);
addpath(genpath(root));

model = 'pt2000_dual_injector_demo';
build_pt2000_v2_model();
load_system(model);

set_param(model, 'StopTime', 'inf');
set_param(model, 'SimulationMode', 'normal');
set_param(model, 'FastRestart', 'off');
set_param(model, 'SignalLogging', 'off');
set_param(model, 'ReturnWorkspaceOutputs', 'off');
try
    set_param(model, 'EnablePacing', 'on', 'PacingRate', '1');
catch
end

open_system(model);
set_param(model, 'ZoomFactor', 'FitSystem');
open_system(model + "/Operator Dashboard");
set_param(model + "/Operator Dashboard", 'ZoomFactor', 'FitSystem');

set_param(model, 'SimulationCommand', 'start');
drawnow;

fprintf('\nPT2000 fast interactive demo is %s.\n', get_param(model, 'SimulationStatus'));
fprintf('Use this mode for sliders/dashboard. Stop the sim before exporting logs.\n\n');
end
