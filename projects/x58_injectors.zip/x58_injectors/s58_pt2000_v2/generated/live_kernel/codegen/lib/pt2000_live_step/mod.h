/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * mod.h
 *
 * Code generation for function 'mod'
 *
 */

#ifndef MOD_H
#define MOD_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
double b_mod(double x);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (mod.h) */
