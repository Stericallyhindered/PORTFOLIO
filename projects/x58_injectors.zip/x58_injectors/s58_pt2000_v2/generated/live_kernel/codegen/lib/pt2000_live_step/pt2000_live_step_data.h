/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * pt2000_live_step_data.h
 *
 * Code generation for function 'pt2000_live_step_data'
 *
 */

#ifndef PT2000_LIVE_STEP_DATA_H
#define PT2000_LIVE_STEP_DATA_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern boolean_T isInitialized_pt2000_live_step;

#endif
/* End of code generation (pt2000_live_step_data.h) */
