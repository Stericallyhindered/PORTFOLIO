/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * pt2000_live_step.h
 *
 * Code generation for function 'pt2000_live_step'
 *
 */

#ifndef PT2000_LIVE_STEP_H
#define PT2000_LIVE_STEP_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void pt2000_live_step(const double u[10], double y[16]);

void pt2000_live_step_init(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (pt2000_live_step.h) */
