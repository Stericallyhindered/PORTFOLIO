/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * pt2000_live_step_data.c
 *
 * Code generation for function 'pt2000_live_step_data'
 *
 */

/* Include files */
#include "pt2000_live_step_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
boolean_T isInitialized_pt2000_live_step = false;

/* End of code generation (pt2000_live_step_data.c) */
