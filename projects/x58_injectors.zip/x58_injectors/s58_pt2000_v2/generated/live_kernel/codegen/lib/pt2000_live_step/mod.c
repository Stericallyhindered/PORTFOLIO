/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * mod.c
 *
 * Code generation for function 'mod'
 *
 */

/* Include files */
#include "mod.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
double b_mod(double x)
{
  double r;
  if (rtIsNaN(x) || rtIsInf(x)) {
    r = rtNaN;
  } else {
    r = fmod(x, 1.0);
    if (r == 0.0) {
      r = 0.0;
    } else if (r < 0.0) {
      r++;
    }
  }
  return r;
}

/* End of code generation (mod.c) */
