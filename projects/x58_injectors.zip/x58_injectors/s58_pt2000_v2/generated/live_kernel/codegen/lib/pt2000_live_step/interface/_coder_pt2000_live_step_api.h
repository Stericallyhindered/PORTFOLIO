/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * _coder_pt2000_live_step_api.h
 *
 * Code generation for function 'pt2000_live_step'
 *
 */

#ifndef _CODER_PT2000_LIVE_STEP_API_H
#define _CODER_PT2000_LIVE_STEP_API_H

/* Include files */
#include "emlrt.h"
#include "mex.h"
#include "tmwtypes.h"
#include <string.h>

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void pt2000_live_step(const real_T u[10], real_T y[16]);

void pt2000_live_step_api(const mxArray *const prhs[1], const mxArray **plhs);

void pt2000_live_step_atexit(void);

void pt2000_live_step_initialize(void);

void pt2000_live_step_terminate(void);

void pt2000_live_step_xil_shutdown(void);

void pt2000_live_step_xil_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (_coder_pt2000_live_step_api.h) */
