/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * pt2000_live_step_initialize.h
 *
 * Code generation for function 'pt2000_live_step_initialize'
 *
 */

#ifndef PT2000_LIVE_STEP_INITIALIZE_H
#define PT2000_LIVE_STEP_INITIALIZE_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void pt2000_live_step_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (pt2000_live_step_initialize.h) */
