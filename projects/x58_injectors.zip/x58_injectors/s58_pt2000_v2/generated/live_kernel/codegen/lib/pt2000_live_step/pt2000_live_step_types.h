/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * pt2000_live_step_types.h
 *
 * Code generation for function 'pt2000_live_step'
 *
 */

#ifndef PT2000_LIVE_STEP_TYPES_H
#define PT2000_LIVE_STEP_TYPES_H

/* Include files */
#include "rtwtypes.h"

#endif
/* End of code generation (pt2000_live_step_types.h) */
