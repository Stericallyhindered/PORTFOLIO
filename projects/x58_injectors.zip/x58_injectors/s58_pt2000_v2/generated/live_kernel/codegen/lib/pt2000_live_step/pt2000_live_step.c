/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * pt2000_live_step.c
 *
 * Code generation for function 'pt2000_live_step'
 *
 */

/* Include files */
#include "pt2000_live_step.h"
#include "mod.h"
#include "pt2000_live_step_data.h"
#include "pt2000_live_step_initialize.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Variable Definitions */
static boolean_T i_not_empty;

/* Function Declarations */
static double rt_roundd_snf(double u);

/* Function Definitions */
static double rt_roundd_snf(double u)
{
  double y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }
  return y;
}

void pt2000_live_step(const double u[10], double y[16])
{
  static double fault[2];
  static double i[2];
  static double lift[2];
  static double mass[2];
  static double state[2];
  static double velocity[2];
  static double boostBus;
  static double phase;
  double b_x;
  double battery;
  double cycleS;
  double d;
  double durationPhase;
  double power;
  double pressure;
  double pulseUs;
  double railPsi;
  double requestMg;
  double rpm;
  double x;
  int channel;
  if (!isInitialized_pt2000_live_step) {
    pt2000_live_step_initialize();
  }
  /* PT2000_LIVE_STEP Fixed-step dual-channel live demonstrator kernel. */
  /*  u: rpm, load%, boost psi, rail psi, lambda, battery V, open ch, short ch,
   */
  /*     enable, reset. y contract is documented in docs/signal_dictionary.md.
   */
  if (!i_not_empty || (u[9] > 0.5)) {
    i_not_empty = true;
    phase = 0.0;
    boostBus = 65.0;
    i[0] = 0.0;
    lift[0] = 0.0;
    velocity[0] = 0.0;
    mass[0] = 0.0;
    state[0] = 0.0;
    fault[0] = 0.0;
    i[1] = 0.0;
    lift[1] = 0.0;
    velocity[1] = 0.0;
    mass[1] = 0.0;
    state[1] = 0.0;
    fault[1] = 0.0;
  }
  rpm = fmax(0.0, u[0]);
  railPsi = fmin(6000.0, fmax(0.0, u[3]));
  battery = fmin(16.5, fmax(8.0, u[5]));
  requestMg = fmin(65.0, ((9.2 * fmin(120.0, fmax(0.0, u[1])) + 240.0) +
                          17.5 * fmin(40.0, fmax(0.0, u[2]))) *
                             fmin(1.0, rpm / 9000.0 + 0.62) /
                             (14.7 * fmin(1.2, fmax(0.65, u[4]))));
  pulseUs = fmin(
      8000.0,
      1000.0 * requestMg / (14.5 * sqrt(fmax(railPsi, 1.0) / 2900.0)) + 650.0);
  cycleS = 120.0 / fmax(rpm, 100.0);
  phase = b_mod(phase + 1.0E-5 / cycleS);
  durationPhase = pulseUs * 1.0E-6 / cycleS;
  power = 0.0;
  pressure = railPsi * 6894.757;
  d = u[8];
  x = u[6];
  b_x = u[7];
  for (channel = 0; channel < 2; channel++) {
    double applied;
    double d1;
    double d2;
    double localPhase;
    unsigned short b_u;
    boolean_T enabled;
    boolean_T openFault;
    boolean_T shortFault;
    localPhase = b_mod(phase - (0.49999999999999994 * (double)channel + 0.08));
    if ((d > 0.5) && (localPhase < durationPhase)) {
      enabled = true;
    } else {
      enabled = false;
    }
    rpm = x;
    if (fabs(x) < 4.503599627370496E+15) {
      if (x >= 0.5) {
        rpm = floor(x + 0.5);
      } else if (x > -0.5) {
        rpm = x * 0.0;
      } else {
        rpm = ceil(x - 0.5);
      }
    }
    openFault = (rpm == (double)channel + 1.0);
    rpm = b_x;
    if (fabs(b_x) < 4.503599627370496E+15) {
      if (b_x >= 0.5) {
        rpm = floor(b_x + 0.5);
      } else if (b_x > -0.5) {
        rpm = b_x * 0.0;
      } else {
        rpm = ceil(b_x - 0.5);
      }
    }
    shortFault = (rpm == (double)channel + 1.0);
    if (openFault) {
      rpm = rt_roundd_snf(fault[channel]);
      if (rpm < 65536.0) {
        if (rpm >= 0.0) {
          b_u = (unsigned short)rpm;
        } else {
          b_u = 0U;
        }
      } else if (rpm >= 65536.0) {
        b_u = MAX_uint16_T;
      } else {
        b_u = 0U;
      }
      fault[channel] = b_u | 1U;
    }
    if (shortFault) {
      rpm = rt_roundd_snf(fault[channel]);
      if (rpm < 65536.0) {
        if (rpm >= 0.0) {
          b_u = (unsigned short)rpm;
        } else {
          b_u = 0U;
        }
      } else if (rpm >= 65536.0) {
        b_u = MAX_uint16_T;
      } else {
        b_u = 0U;
      }
      fault[channel] = b_u | 6U;
    }
    if (enabled && (localPhase * cycleS * 1.0E+6 < 550.0) &&
        (i[channel] < 11.0)) {
      state[channel] = 2.0;
      applied = boostBus;
    } else if (enabled && (i[channel] < 3.4)) {
      state[channel] = 4.0;
      applied = battery;
    } else if (enabled && (i[channel] > 4.2)) {
      state[channel] = 3.0;
      applied = 0.0;
    } else if (enabled) {
      if (state[channel] == 4.0) {
        applied = battery;
      } else {
        applied = 0.0;
      }
    } else if (i[channel] > 0.05) {
      state[channel] = 5.0;
      applied = -55.0;
    } else {
      state[channel] = 6.0;
      applied = 0.0;
    }
    rpm = 1.25;
    if (shortFault) {
      rpm = 0.08;
    }
    if (openFault) {
      d2 = 0.0;
      i[channel] = 0.0;
    } else {
      d1 = i[channel];
      d2 = fmin(18.0, fmax(0.0, d1 + 1.0E-5 * (applied - rpm * d1) /
                                         (8.000000000000005E-5 * lift[channel] /
                                              4.5E-5 +
                                          0.00028)));
      i[channel] = d2;
    }
    d1 = lift[channel];
    rpm = velocity[channel];
    rpm += 1.0E-5 *
           (((((0.55 * (d2 * d2) - pressure * 9.5E-7) - 18.0) - 20000.0 * d1) -
             2.5 * rpm) /
            0.0015);
    velocity[channel] = rpm;
    rpm = fmin(4.5E-5, fmax(0.0, d1 + 1.0E-5 * rpm));
    lift[channel] = rpm;
    if ((rpm <= 0.0) || (rpm >= 4.5E-5)) {
      velocity[channel] = 0.0;
    }
    if (enabled || (rpm > 0.0)) {
      mass[channel] += 6.839999999999999E-7 * (rpm / 4.5E-5) *
                       sqrt(1490.0 * pressure) * 1000.0 * 1.0E-5 * 1000.0;
    }
    if (!enabled && (d2 < 0.05) && (rpm == 0.0) && (localPhase > 0.2)) {
      mass[channel] = 0.0;
    }
    power += fmax(applied, 0.0) * d2;
  }
  boostBus = fmin(
      72.0, fmax(0.0, boostBus + 1.0E-5 * ((65.0 - boostBus) / 0.0015 +
                                           (battery * 35.0 - power) /
                                               fmax(boostBus * 0.0047, 1.0))));
  rpm = sqrt(1490.0 * railPsi * 6894.757);
  y[0] = requestMg;
  y[1] = pulseUs / 1000.0;
  y[2] = i[0];
  y[3] = i[1];
  y[4] = lift[0] * 1.0E+6;
  y[5] = lift[1] * 1.0E+6;
  y[6] = 6.839999999999999E-7 * (lift[0] / 4.5E-5) * rpm * 1000.0;
  y[7] = 6.839999999999999E-7 * (lift[1] / 4.5E-5) * rpm * 1000.0;
  y[8] = mass[0];
  y[9] = mass[1];
  y[10] = state[0];
  y[11] = state[1];
  y[12] = boostBus;
  y[13] = fault[0];
  y[14] = fault[1];
  y[15] = phase;
}

void pt2000_live_step_init(void)
{
  i_not_empty = false;
}

/* End of code generation (pt2000_live_step.c) */
