/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * pt2000_live_step_terminate.h
 *
 * Code generation for function 'pt2000_live_step_terminate'
 *
 */

#ifndef PT2000_LIVE_STEP_TERMINATE_H
#define PT2000_LIVE_STEP_TERMINATE_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void pt2000_live_step_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (pt2000_live_step_terminate.h) */
