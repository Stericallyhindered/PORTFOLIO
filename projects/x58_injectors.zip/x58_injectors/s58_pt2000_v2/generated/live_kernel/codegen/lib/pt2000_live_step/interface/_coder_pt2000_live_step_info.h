/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * _coder_pt2000_live_step_info.h
 *
 * Code generation for function 'pt2000_live_step'
 *
 */

#ifndef _CODER_PT2000_LIVE_STEP_INFO_H
#define _CODER_PT2000_LIVE_STEP_INFO_H

/* Include files */
#include "mex.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (_coder_pt2000_live_step_info.h) */
