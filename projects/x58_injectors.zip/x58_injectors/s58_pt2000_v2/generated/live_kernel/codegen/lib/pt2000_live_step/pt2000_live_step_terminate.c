/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * pt2000_live_step_terminate.c
 *
 * Code generation for function 'pt2000_live_step_terminate'
 *
 */

/* Include files */
#include "pt2000_live_step_terminate.h"
#include "pt2000_live_step_data.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void pt2000_live_step_terminate(void)
{
  isInitialized_pt2000_live_step = false;
}

/* End of code generation (pt2000_live_step_terminate.c) */
