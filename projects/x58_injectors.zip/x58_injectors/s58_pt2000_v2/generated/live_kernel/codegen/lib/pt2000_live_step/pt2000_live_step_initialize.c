/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * pt2000_live_step_initialize.c
 *
 * Code generation for function 'pt2000_live_step_initialize'
 *
 */

/* Include files */
#include "pt2000_live_step_initialize.h"
#include "pt2000_live_step.h"
#include "pt2000_live_step_data.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void pt2000_live_step_initialize(void)
{
  pt2000_live_step_init();
  isInitialized_pt2000_live_step = true;
}

/* End of code generation (pt2000_live_step_initialize.c) */
