/*
 * Trial License - for use to evaluate programs for possible purchase as
 * an end-user only.
 *
 * _coder_pt2000_live_step_info.c
 *
 * Code generation for function 'pt2000_live_step'
 *
 */

/* Include files */
#include "_coder_pt2000_live_step_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *c_emlrtMexFcnResolvedFunctionsI(void);

/* Function Definitions */
static const mxArray *c_emlrtMexFcnResolvedFunctionsI(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[6] = {
      "789ced56cd6ed340105e5b49d34ab4840beab12f50642cda461c49295495a15282a8c028"
      "35c9b636f19fbc4e9af425e0d823c71e39f6c89147e0d2f7e048527b"
      "1267e4614da4a61c186935fef2edce37de59ef8429fb86c2185b63895d2d257e35c5d5d4"
      "ab6cd630af101eaccc4a33eb80ff9cfa76e0c77c1027c0b73c3e59e9",
      "f8612f6e0e432e4620e22270fbbc73c39c382e6f3a1e6f64c1ab31f2f632d4048ca9f173"
      "dde6ed6ea3e7b1c816d30cdd2c98ecc731f1be25c97e60c3fb81e781"
      "5e38a79e4260ac073e8c754dd35aaed3e72d11f310f47f12f11fa07838be926668d45f37"
      "129c1c2411478e7f3a7dbf01111f3023f825a48bf5815f9ffe74ada6",
      "f3b203f2f841e814dd678bc8a38af8f7cf3fd49f9a6f048f84693f391f9abb41bbe7713f"
      "16663de8f081a96bfaf6a6b6b3f978db0cbad6d03c0ba2ae29b66aad"
      "b4427ddd148ed773add8097c1397ed9197eac8ceebfd82ef45edef2a5bbef1cefab5b248"
      "bdfdd2d6c122f5c0ee4a8ffa3e8a9ecb87845e15f17bfa19ff64889d",
      "dab3774d839f8b9727a747c68b691e87121d591e8cc08b8affab92bf7ea560fc8b4a7e7c"
      "15f10cf54ffb96fbe70ae201c3bd0b36b9cfcbf97a7f7f9fcfc619f7"
      "d1b79115863c6ab5327a36a127ababec7e87f81b4afe7a595dbf4be2ab685e29fdad361a"
      "472ce9cb5f47e33233be8d86e50f273d8e325c7bd087f1275388e7bc",
      "795719bc8678c017a99ff73eab208ce7d710af220c1eeadd6101ebb18fcc657c26cf43a2"
      "ceb27344e981c9fe6715fd4e1981e13bfdd7f58f89f8f724fab2fd2d"
      "137ded7f3d6f577f79ce7b11e25d12f155c4e37ef785887b57fd0eec37d63c8c5a",
      ""};
  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 3800U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[7] = {
      "QualifiedName",    "NumberOfInputs", "NumberOfOutputs", "ConstantInputs",
      "ResolvedFilePath", "TimeStamp",      "Visible"};
  const char_T *propFieldName[7] = {
      "Version",      "ResolvedFunctions", "Checksum", "EntryPoints",
      "CoverageInfo", "IsPolymorphic",     "AuxData"};
  uint8_T v[216] = {
      0U,   1U,   73U,  77U,  0U,   0U,   0U,   0U,   14U,  0U,   0U,   0U,
      200U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,
      2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,   5U,   0U,   4U,   0U,
      17U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,   17U,  0U,   0U,   0U,
      67U,  108U, 97U,  115U, 115U, 69U,  110U, 116U, 114U, 121U, 80U,  111U,
      105U, 110U, 116U, 115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      14U,  0U,   0U,   0U,   112U, 0U,   0U,   0U,   6U,   0U,   0U,   0U,
      8U,   0U,   0U,   0U,   2U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   0U,   0U,   8U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,
      0U,   0U,   0U,   0U,   1U,   0U,   0U,   0U,   0U,   0U,   0U,   0U,
      5U,   0U,   4U,   0U,   14U,  0U,   0U,   0U,   1U,   0U,   0U,   0U,
      56U,  0U,   0U,   0U,   81U,  117U, 97U,  108U, 105U, 102U, 105U, 101U,
      100U, 78U,  97U,  109U, 101U, 0U,   77U,  101U, 116U, 104U, 111U, 100U,
      115U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   80U,  114U, 111U, 112U,
      101U, 114U, 116U, 105U, 101U, 115U, 0U,   0U,   0U,   0U,   72U,  97U,
      110U, 100U, 108U, 101U, 0U,   0U,   0U,   0U,   0U,   0U,   0U,   0U};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, "QualifiedName",
                emlrtMxCreateString("pt2000_live_step"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, "ResolvedFilePath",
      emlrtMxCreateString(
          "C:\\Users\\h4zy\\Documents\\Codex\\2026-07-16\\okay\\work\\s58_"
          "pt2000_v2\\simulation\\pt2000_live_step.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(740183.4171296296));
  emlrtSetField(xEntryPoints, 0, "Visible", emlrtMxCreateLogicalScalar(true));
  xResult =
      emlrtCreateStructMatrix(1, 1, 7, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("26.1.0.3276743 (R2026a) Update 3"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)c_emlrtMexFcnResolvedFunctionsI());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("rlgCDerBG3dzpuB3Mv0KgH"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  emlrtSetField(xResult, 0, "AuxData",
                emlrtMxCreateRowVectorUINT8((const uint8_T *)&v, 216U));
  return xResult;
}

/* End of code generation (_coder_pt2000_live_step_info.c) */
