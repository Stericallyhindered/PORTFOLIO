function pt2000_run_log(action)
%PT2000_RUN_LOG Persistent text and Simulation Data Inspector run logging.
root=fileparts(mfilename('fullpath')); folder=fullfile(root,'logs');
if ~isfolder(folder), mkdir(folder); end
switch lower(action)
    case 'start'
        diary(fullfile(folder,'latest_run.log'));
        fprintf('PT2000 V2 simulation start %s\n',datetime('now'));
        fprintf('Injector parameter provenance: ESTIMATE; releaseApproved=false\n');
    case 'stop'
        fprintf('PT2000 V2 simulation stop %s\n',datetime('now'));
        writeLatestSignalSnapshot();
        try
            Simulink.sdi.save(fullfile(folder,'latest_run.mldatx'));
        catch exception
            fprintf('SDI archive warning: %s\n',exception.message);
        end
        diary off;
end
end

function writeLatestSignalSnapshot()
vars = evalin('base','whos');
names = string({vars.name});
signals = [
    "PT2K_3", "Current Ch1 A"
    "PT2K_4", "Current Ch2 A"
    "PT2K_5", "Lift Ch1 um"
    "PT2K_6", "Lift Ch2 um"
    "PT2K_7", "Flow Ch1 mg_per_ms"
    "PT2K_8", "Flow Ch2 mg_per_ms"
    "PT2K_9", "Mass Ch1 mg"
    "PT2K_10", "Mass Ch2 mg"
    "PT2K_13", "Boost Bus V"
    "PT2K_14", "Fault Ch1 bits"
    "PT2K_15", "Fault Ch2 bits"
];
fprintf('PT2000 latest signal snapshot:\n');
for k = 1:size(signals,1)
    if any(names == signals(k,1))
        ts = evalin('base', signals(k,1));
        if isa(ts,'timeseries') && ~isempty(ts.Data)
            fprintf('  %-20s %12.4f at t=%8.4f s\n', ...
                signals(k,2), squeeze(ts.Data(end)), ts.Time(end));
        end
    end
end
end
