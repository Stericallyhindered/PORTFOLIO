function modelFile = build_pt2000_v2_model()
%BUILD_PT2000_V2_MODEL Generate the live Simulink engineering demonstrator.
root = fileparts(mfilename('fullpath'));
addpath(genpath(root));
model = 'pt2000_dual_injector_demo';
modelFile = fullfile(root, model + ".slx");
if bdIsLoaded(model), close_system(model,0); end
if isfile(modelFile), delete(modelFile); end
new_system(model); open_system(model);
set_param(model,'SolverType','Fixed-step','Solver','FixedStepDiscrete', ...
    'FixedStep','1e-5','StopTime','inf','BlockReduction','off', ...
    'OptimizeBlockIOStorage','off','DefaultParameterBehavior','Tunable', ...
    'InlineParams','off','SignalLogging','off','SignalLoggingName','logsout');

addInputs(model);
add_block('simulink/Ports & Subsystems/Subsystem',[model '/Local Crank Cam Synchronization'], ...
    'Position',[300 340 510 475],'BackgroundColor','yellow');
makeCrankCamSync([model '/Local Crank Cam Synchronization']);
add_block('simulink/Ports & Subsystems/Subsystem',[model '/CAN FD Rx and E2E Safety'], ...
    'Position',[300 115 510 285],'BackgroundColor','lightBlue');
makeCanSafety([model '/CAN FD Rx and E2E Safety']);
add_block('simulink/Ports & Subsystems/Subsystem',[model '/Fuel Scheduler Injector Timing and SPI START'], ...
    'Position',[585 115 800 285],'BackgroundColor','green');
makeMcuInterface([model '/Fuel Scheduler Injector Timing and SPI START']);
add_block('simulink/Ports & Subsystems/Subsystem',[model '/PT2000 Device Power Stages and Injector Plant'], ...
    'Position',[880 95 1125 305],'BackgroundColor','orange');
addKernel([model '/PT2000 Device Power Stages and Injector Plant']);
add_block('simulink/Signal Routing/Demux',[model '/Engineering Signal Decode'], ...
    'Outputs','25','Position',[1235 80 1240 700]);
add_line(model,'Vehicle CAN FD Commands/1','CAN FD Rx and E2E Safety/1','autorouting','on');
add_line(model,'CAN FD Rx and E2E Safety/1','Fuel Scheduler Injector Timing and SPI START/1','autorouting','on');
add_line(model,'Vehicle CAN FD Commands/2','Local Crank Cam Synchronization/1','autorouting','on');
add_line(model,'Local Crank Cam Synchronization/1','Fuel Scheduler Injector Timing and SPI START/2','autorouting','on');
add_line(model,'Local Crank Cam Synchronization/2','Fuel Scheduler Injector Timing and SPI START/3','autorouting','on');
add_line(model,'Fuel Scheduler Injector Timing and SPI START/1','PT2000 Device Power Stages and Injector Plant/1','autorouting','on');
add_line(model,'PT2000 Device Power Stages and Injector Plant/1','Engineering Signal Decode/1','autorouting','on');

names = {'Fuel Request mg','Pulse Width ms','Current Ch1 A','Current Ch2 A', ...
    'Lift Ch1 um','Lift Ch2 um','Flow Ch1 mg_per_ms','Flow Ch2 mg_per_ms', ...
    'Mass Ch1 mg','Mass Ch2 mg','State Ch1','State Ch2','Boost Bus V', ...
    'Fault Ch1','Fault Ch2','Engine Cycle Phase','Boost Target psi','Boost Actual psi', ...
    'Injection Events per sec','Engine Cycle ms','Crank Angle deg','Active Cylinder', ...
    'SOI BTDC deg','Injection Duration deg','Event Angle deg'};
for k=1:25
    zoh=model + "/UI Publish " + string(names{k});
    block=model + "/" + string(names{k});
    publishTs = '2e-2';
    if ismember(k,[3 4])
        % Keep the electrical kernel at 10 us; publish readable scope points.
        publishTs = '5e-4';
    elseif ismember(k,[7 8 9 10])
        publishTs = '1e-5';
    end
    add_block('simulink/Discrete/Zero-Order Hold',zoh, ...
        'SampleTime',publishTs,'Position',[1300 30+30*k 1335 50+30*k]);
    add_block('simulink/Signal Attributes/Signal Specification',block, ...
        'Position',[1410 30+30*k 1560 50+30*k]);
    add_line(model,"Engineering Signal Decode/"+k,"UI Publish "+string(names{k})+"/1",'autorouting','on');
    add_line(model,"UI Publish "+string(names{k})+"/1",string(names{k})+"/1",'autorouting','on');
end
addLogging(model,names,root);
addDashboard(model,names);
addArchitectureNotes(model);

set_param(model,'PreLoadFcn',"addpath(genpath('"+replace(root,"'","''")+"'));", ...
    'StartFcn',"pt2000_run_log('start');",'StopFcn',"pt2000_run_log('stop');");
save_system(model,modelFile);
open_system([model '/Operator Dashboard']);
set_param([model '/Operator Dashboard'],'ZoomFactor','FitSystem');
end

function addInputs(model)
sub=[model '/Vehicle CAN FD Commands'];
add_block('simulink/Ports & Subsystems/Subsystem',sub,'Position',[35 80 225 320], ...
    'BackgroundColor','cyan'); Simulink.SubSystem.deleteContents(sub);
set_param(sub,'TreatAsAtomicUnit','on');
labels={'RPM','Load pct','Boost target psi','Rail psi','Lambda','Battery V', ...
    'Open fault ch','Short fault ch','Driver enable','Reset'};
values=[3500 75 20 2900 0.82 13.5 0 0 1 0];
for k=1:10
    blockLabel = labels{k};
    if strcmp(blockLabel,'Boost target psi')
        blockLabel = 'Boost psi';
    end
    add_block('simulink/Sources/Constant',[sub '/' blockLabel], ...
        'Value',string(values(k)),'SampleTime','2e-2', ...
        'Position',[20 15+35*k 105 35+35*k]);
end
add_block('simulink/Signal Routing/Mux',[sub '/Command Payload'],'Inputs','10', ...
    'Position',[145 35 150 385]);
add_block('simulink/Ports & Subsystems/Out1',[sub '/CAN FD payload'], ...
    'Position',[190 198 220 212]);
add_block('simulink/Ports & Subsystems/Out1',[sub '/Local RPM sensor model'], ...
    'Port','2','Position',[190 420 220 434]);
for k=1:10
    blockLabel = labels{k};
    if strcmp(blockLabel,'Boost target psi')
        blockLabel = 'Boost psi';
    end
    add_line(sub,blockLabel+"/1","Command Payload/"+k);
end
add_line(sub,'Command Payload/1','CAN FD payload/1');
add_line(sub,'RPM/1','Local RPM sensor model/1');
end

function makeCrankCamSync(sub)
Simulink.SubSystem.deleteContents(sub);
add_block('simulink/Ports & Subsystems/In1',[sub '/Engine speed estimate'], ...
    'Position',[20 65 50 79]);
block=[sub '/60-2 crank and cam capture model'];
add_block('simulink/User-Defined Functions/MATLAB Function',block, ...
    'Position',[85 35 270 105]);
chart = find(sfroot,'-isa','Stateflow.EMChart','Path',block);
chart.Script = sprintf(['function [rpmLocal,crankAngle] = fcn(rpmInput)\n' ...
    '%%#codegen\n' ...
    'persistent phase\n' ...
    'if isempty(phase), phase = 0; end\n' ...
    'dt = 1e-5; rpmLocal = max(0,rpmInput);\n' ...
    'phase = mod(phase + dt*rpmLocal/120,1);\n' ...
    '%% 60-2 crank wheel capture, 6 deg resolution over a 720 deg cycle.\n' ...
    'crankAngle = mod(floor(phase*120)*6,720);\n' ...
    'end\n']);
add_block('simulink/Ports & Subsystems/Out1',[sub '/Local RPM'], ...
    'Port','1','Position',[310 45 340 59]);
add_block('simulink/Ports & Subsystems/Out1',[sub '/Synchronized crank angle deg'], ...
    'Port','2','Position',[310 85 340 99]);
add_line(sub,'Engine speed estimate/1','60-2 crank and cam capture model/1');
add_line(sub,'60-2 crank and cam capture model/1','Local RPM/1');
add_line(sub,'60-2 crank and cam capture model/2','Synchronized crank angle deg/1');
add_block('built-in/Note',[sub '/Local sensor path: 60-2 crank plus cam phase; not CAN-timed'], ...
    'Position',[35 125 310 155]);
end

function makeCanSafety(sub)
Simulink.SubSystem.deleteContents(sub);
add_block('simulink/Ports & Subsystems/In1',[sub '/Command bus'],'Position',[20 90 50 104]);
add_block('simulink/Signal Routing/Demux',[sub '/Decode signals'],'Outputs','10','Position',[75 35 80 330]);
add_block('simulink/Signal Routing/Mux',[sub '/Validated command bus'],'Inputs','10','Position',[260 35 265 330]);
limits=[0 8000;0 120;0 40;0 6000;0.65 1.2;8 16.5;0 2;0 2;0 1;0 1];
for k=1:10
    b=sub + "/Range validation " + string(k);
    add_block('simulink/Discontinuities/Saturation',b,'LowerLimit',string(limits(k,1)), ...
        'UpperLimit',string(limits(k,2)),'Position',[125 15+30*k 220 35+30*k]);
    add_line(sub,"Decode signals/"+k,"Range validation "+k+"/1");
    add_line(sub,"Range validation "+k+"/1","Validated command bus/"+k);
end
add_block('simulink/Ports & Subsystems/Out1',[sub '/Validated bus'],'Position',[310 175 340 189]);
add_line(sub,'Command bus/1','Decode signals/1'); add_line(sub,'Validated command bus/1','Validated bus/1');
add_block('built-in/Note',[sub '/CRC counter and 15 ms timeout verified in network tests'],'Position',[90 350 330 390]);
end

function makeMcuInterface(sub)
Simulink.SubSystem.deleteContents(sub);
add_block('simulink/Ports & Subsystems/In1',[sub '/Validated command bus'],'Position',[20 90 50 104]);
add_block('simulink/Ports & Subsystems/In1',[sub '/Local RPM'],'Port','2','Position',[20 145 50 159]);
add_block('simulink/Ports & Subsystems/In1',[sub '/Synchronized crank angle'],'Port','3','Position',[20 200 50 214]);
add_block('simulink/Signal Routing/Demux',[sub '/Decode CAN commands'],'Outputs','10','Position',[75 35 80 275]);
add_block('simulink/Signal Routing/Mux',[sub '/Local timing command vector'],'Inputs','11','Position',[190 35 195 300]);
add_block('simulink/Discrete/Zero-Order Hold',[sub '/100 us controller task'], ...
    'SampleTime','1e-5','Position',[225 115 330 155]);
add_block('simulink/Ports & Subsystems/Out1',[sub '/SPI and START abstraction'],'Position',[375 125 405 139]);
add_line(sub,'Validated command bus/1','Decode CAN commands/1');
add_line(sub,'Local RPM/1','Local timing command vector/1');
for k=2:10
    add_line(sub,"Decode CAN commands/"+k,"Local timing command vector/"+k);
end
add_line(sub,'Synchronized crank angle/1','Local timing command vector/11');
add_line(sub,'Local timing command vector/1','100 us controller task/1');
add_line(sub,'100 us controller task/1','SPI and START abstraction/1');
add_block('built-in/Note',[sub '/CAN commands plus locally captured crank-cam timing'], ...
    'Position',[75 305 350 340]);
end

function addKernel(sub)
Simulink.SubSystem.deleteContents(sub);
add_block('simulink/Ports & Subsystems/In1',[sub '/SPI and START command'], ...
    'Position',[20 100 50 114]);
block=[sub '/Six microcore behavioral kernel'];
add_block('simulink/User-Defined Functions/MATLAB Function',block, ...
    'Position',[100 65 300 150]);
chart = find(sfroot,'-isa','Stateflow.EMChart','Path',block);
chart.Script = sprintf(['function y = fcn(u)\n' ...
    '%%#codegen\n' ...
    'y = pt2000_live_step(u);\n' ...
    'end\n']);
add_block('simulink/Ports & Subsystems/Out1',[sub '/Driver and plant signals'], ...
    'Position',[350 100 380 114]);
add_line(sub,'SPI and START command/1','Six microcore behavioral kernel/1');
add_line(sub,'Six microcore behavioral kernel/1','Driver and plant signals/1');
add_block('built-in/Note',[sub '/External HS LS MOSFETs current sense flyback EOI'], ...
    'Position',[65 180 340 220]);
end

function addLogging(model,names,root)
sub=[model '/Persistent Logging'];
add_block('simulink/Ports & Subsystems/Subsystem',sub,'Position',[1660 520 1855 680], ...
    'BackgroundColor','gray'); Simulink.SubSystem.deleteContents(sub);
selected=[3 4 5 6 7 8 9 10 13 14 15];
for j=1:numel(selected)
    k=selected(j); in=sub + "/In" + string(j); log=sub + "/Log " + string(names{k});
    add_block('simulink/Ports & Subsystems/In1',in,'Port',string(j), ...
        'Position',[15 10+28*j 45 24+28*j]);
    add_block('simulink/Sinks/To Workspace',log,'VariableName','PT2K_'+string(k), ...
        'SaveFormat','Timeseries','MaxDataPoints','20000', ...
        'Position',[90 7+28*j 205 27+28*j]);
    add_line(sub,"In"+j+"/1","Log "+names{k}+"/1");
    add_line(model,names{k}+"/1","Persistent Logging/"+j,'autorouting','on');
end
set_param(sub,'UserData',fullfile(root,'logs'));
end

function addDashboard(model,names)
dash=[model '/Operator Dashboard'];
add_block('simulink/Ports & Subsystems/Subsystem',dash,'Position',[600 400 860 520], ...
    'BackgroundColor','cyan'); Simulink.SubSystem.deleteContents(dash);
controls={'RPM',600,8000;'Load pct',0,120;'Boost psi',0,40;'Rail psi',700,5000; ...
    'Lambda',0.65,1.2;'Battery V',8,16.5;'Open fault ch',0,2; ...
    'Short fault ch',0,2;'Driver enable',0,1;'Reset',0,1};
controlLabels={'RPM command','Load command','Boost target command','Rail pressure command', ...
    'Lambda command','Battery command','Diagnostic open fault selector: 0 off, 1 CH1, 2 CH2', ...
    'Diagnostic short fault selector: 0 off, 1 CH1, 2 CH2','Driver enable command','Fault reset command'};
for k=1:size(controls,1)
    row=mod(k-1,5); col=floor((k-1)/5); x=35+col*390; y=45+row*100;
    b=dash + "/" + string(controlLabels{k});
    add_block('simulink_hmi_blocks/Slider',b,'Position',[x y x+260 y+62], ...
        'ShowName','on','ShowInitialText','off','LabelPosition','Hide','Limits',[controls{k,2} controls{k,3}]);
    source=Simulink.HMI.ParamSourceInfo; source.BlockPath=Simulink.BlockPath( ...
        model + "/Vehicle CAN FD Commands/" + string(controls{k,1})); source.ParamName='Value';
    set_param(b,'Binding',source);
    readout=dash + "/" + string(controlLabels{k}) + " value";
    add_block('simulink_hmi_blocks/Display',readout,'Position',[x+275 y+7 x+355 y+55], ...
        'ShowName','off','ShowInitialText','off','Format','Custom','FormatString','%.2f');
    set_param(readout,'Binding',signalSpec(model + "/Vehicle CAN FD Commands/" + string(controls{k,1}),1));
end
displayIndexes=[1 2 17 18 19 20 21 22 23 24 25 3 4 5 6 7 8 9 10 11 12 13 16 14 15];
displayLabels={'Fuel request','Pulse width','Boost target','Boost actual', ...
    'Injection Hz','Cycle ms','Crank angle','Active cyl','SOI BTDC','Duration deg', ...
    'Event angle','Current CH1','Current CH2','Lift CH1','Lift CH2', ...
    'Flow CH1','Flow CH2','Mass CH1','Mass CH2','State CH1','State CH2', ...
    'Boost bus','Cycle phase','Fault CH1','Fault CH2'};
for j=1:numel(displayIndexes)
    k=displayIndexes(j); col=mod(j-1,4); row=floor((j-1)/4);
    x=850+col*205; y=35+row*76;
    b=dash + "/" + string(displayLabels{j});
    add_block('simulink_hmi_blocks/Display',b,'Position',[x y x+175 y+50], ...
        'ShowName','on','ShowInitialText','off','Format','Custom','FormatString','%.3f');
    set_param(b,'Binding',signalSpec([model '/' names{k}],1));
end
addGauge(dash,'Engine speed gauge',[model '/Vehicle CAN FD Commands/RPM'],[850 520 1045 705],[0 8000]);
addGauge(dash,'Boost target gauge',[model '/Boost Target psi'],[1090 520 1285 705],[0 40]);
addGauge(dash,'Actual boost gauge',[model '/Boost Actual psi'],[1330 520 1525 705],[0 40]);
addGauge(dash,'Rail pressure gauge',[model '/Vehicle CAN FD Commands/Rail psi'],[1570 520 1765 705],[0 5000]);
addScope(dash,'Dual coil current',{signalSpec([model '/Current Ch1 A'],1),signalSpec([model '/Current Ch2 A'],1)},[35 760 760 1045],[0 20],0.04);
addScope(dash,'Fuel flow and delivered mass',{signalSpec([model '/Flow Ch1 mg_per_ms'],1),signalSpec([model '/Flow Ch2 mg_per_ms'],1), ...
    signalSpec([model '/Mass Ch1 mg'],1),signalSpec([model '/Mass Ch2 mg'],1)},[800 760 1525 1045],[0 140]);
addScope(dash,'Boost target and actual',{signalSpec([model '/Boost Target psi'],1),signalSpec([model '/Boost Actual psi'],1)},[1565 760 2230 1045],[0 42]);
end

function addGauge(parent,name,source,pos,limits,port)
if nargin < 6
    port = 1;
end
b=[parent '/' name]; add_block('simulink_hmi_blocks/Gauge',b,'Position',pos, ...
    'ShowName','on','ShowInitialText','off','Limits',limits);
if contains(source,'Vehicle CAN FD Commands')
    % Gauge receives the tunable constant output, while the slider edits its Value.
end
set_param(b,'Binding',signalSpec(source,port));
end

function addScope(parent,name,specs,pos,yLimits,timeSpan)
if nargin < 6
    timeSpan = 0.15;
end
b=[parent '/' name]; add_block('simulink_hmi_blocks/Dashboard Scope',b, ...
    'Position',pos,'ShowName','on','ShowInitialText','off','Binding',specs, ...
    'TimeSpan',num2str(timeSpan),'UpdateMode','Scroll','LegendPosition','Top','YLimits',yLimits);
end

function spec=signalSpec(source,port)
spec=Simulink.HMI.SignalSpecification; spec.BlockPath=Simulink.BlockPath(source); spec.OutputPortIndex=port;
end

function addArchitectureNotes(model)
add_block('built-in/Note',[model '/CAN FD 500 kbit arbitration 2 Mbit data BRS'], ...
    'Position',[285 35 525 65]);
add_block('built-in/Note',[model '/Input boundary local sensors vs CAN commands'], ...
    'Position',[35 350 500 415]);
add_block('built-in/Note',[model '/Control order CAN Rx safety fuel schedule timing SPI PT2000 plant feedback'], ...
    'Position',[690 35 1165 65]);
add_block('built-in/Note',[model '/Two PT2000-style physical channels with direct scope outputs'], ...
    'Position',[870 330 1175 365]);
add_block('built-in/Note',[model '/Injector parameters ESTIMATE not OEM measured'], ...
    'Position',[1180 15 1435 45]);
end
