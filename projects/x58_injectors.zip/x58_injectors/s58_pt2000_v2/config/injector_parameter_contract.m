function injector = injector_parameter_contract()
%INJECTOR_PARAMETER_CONTRACT Replaceable injector plant characterization.
% Values are bounded engineering estimates, not measured S58 injector data.

injector.meta.name = "Uncharacterized GDI solenoid injector";
injector.meta.revision = "0.1.0";
injector.meta.provenance = "ESTIMATE";
injector.meta.releaseApproved = false;

injector.electrical.resistanceOhm = bounded(1.25, 0.9, 1.8, "ohm");
injector.electrical.inductanceClosedH = bounded(280e-6, 150e-6, 500e-6, "H");
injector.electrical.inductanceOpenH = bounded(360e-6, 180e-6, 650e-6, "H");
injector.electrical.copperTempCoeffPerC = bounded(0.00393, 0.0037, 0.0042, "1/degC");

injector.mechanical.armatureMassKg = bounded(1.5e-3, 0.5e-3, 4e-3, "kg");
injector.mechanical.springRateNPerM = bounded(2.0e4, 0.8e4, 5e4, "N/m");
injector.mechanical.dampingNsPerM = bounded(2.5, 0.5, 8, "N*s/m");
injector.mechanical.maxLiftM = bounded(45e-6, 20e-6, 90e-6, "m");
injector.mechanical.preloadN = bounded(18, 5, 45, "N");
injector.mechanical.magneticForceNPerA2 = bounded(0.55, 0.20, 0.90, "N/A^2");

injector.hydraulic.dischargeCoefficient = bounded(0.72, 0.45, 0.9, "1");
injector.hydraulic.effectiveAreaM2 = bounded(9.5e-7, 0.3e-6, 2.0e-6, "m^2");
injector.hydraulic.fuelDensityKgPerM3 = bounded(745, 690, 790, "kg/m^3");
injector.hydraulic.referenceRailPsi = bounded(2900, 700, 5000, "psi");
end

function value = bounded(nominal, minimum, maximum, unit)
value.nominal = nominal;
value.minimum = minimum;
value.maximum = maximum;
value.unit = unit;
value.provenance = "ESTIMATE";
end
