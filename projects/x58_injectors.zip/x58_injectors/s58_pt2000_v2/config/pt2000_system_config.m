function cfg = pt2000_system_config()
%PT2000_SYSTEM_CONFIG Project-level timing, network and driver configuration.

cfg.meta.revision = "0.1.0";
cfg.meta.target = "NXP PT2000 behavioral model";
cfg.arch.injectorCommandCount = 6;
cfg.arch.simulatedPhysicalChannels = 2;

cfg.timing.controllerStepS = 100e-6;
cfg.timing.pt2000MicrocoreStepS = 1e-6;
cfg.timing.powerStageStepS = 0.25e-6;
cfg.timing.vehicleCanStepS = 1e-3;

cfg.can.type = "CAN-FD";
cfg.can.arbitrationBitRate = 500000;
cfg.can.dataBitRate = 2000000;
cfg.can.samplePointPct = 80;
cfg.can.maxUtilizationPct = 60;
cfg.can.commandTimeoutMs = 15;

cfg.spi.clockHz = 5000000;
cfg.spi.mode = 1;
cfg.spi.cpol = 0;
cfg.spi.cpha = 1;
cfg.spi.wordBits = 16;
cfg.spi.chipSelectActiveLow = true;
cfg.spi.transactionTimeoutUs = 100;

cfg.driver.boostTargetV = 65;
cfg.driver.boostMinV = 55;
cfg.driver.boostMaxV = 72;
cfg.driver.peakCurrentA = 11;
cfg.driver.peakTimeoutUs = 550;
cfg.driver.holdLowA = 3.4;
cfg.driver.holdHighA = 4.2;
cfg.driver.flybackClampV = -55;
cfg.driver.currentSenseOhm = 0.015;
cfg.driver.maxChannelCurrentA = 18;
cfg.driver.maxConcurrentBoostChannels = 1;

cfg.injector = injector_parameter_contract();
end
