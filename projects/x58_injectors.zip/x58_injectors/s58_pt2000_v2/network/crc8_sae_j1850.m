function crc = crc8_sae_j1850(bytes)
%CRC8_SAE_J1850 CRC-8/J1850: poly 0x1D, init/xorout 0xFF, no reflection.
arguments
    bytes (1,:) uint8
end
crc = uint8(255);
for byte = bytes
    crc = bitxor(crc, byte);
    for bitIndex = 1:8
        if bitand(crc, uint8(128)) ~= 0
            crc = bitxor(bitshift(crc, 1), uint8(hex2dec('1D')));
        else
            crc = bitshift(crc, 1);
        end
    end
end
crc = bitxor(crc, uint8(255));
end
