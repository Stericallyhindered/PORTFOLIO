function results = diagnose_dbc_messages(dbcPath)
%DIAGNOSE_DBC_MESSAGES Load each BO_ section independently with canDatabase.
text = fileread(dbcPath);
starts = regexp(text, '(?m)^BO_ ');
tail = regexp(text, '(?m)^BA_DEF_ ', 'once');
if isempty(starts) || isempty(tail)
    error('PT2000:DBCStructure', 'DBC messages or attribute section not found.');
end

header = extractBefore(text, starts(1));
names = strings(numel(starts), 1);
passed = false(numel(starts), 1);
details = strings(numel(starts), 1);
for index = 1:numel(starts)
    blockEnd = tail - 1;
    if index < numel(starts)
        blockEnd = starts(index + 1) - 1;
    end
    block = extractBetween(text, starts(index), blockEnd);
    if iscell(block)
        block = block{1};
    end
    token = regexp(block, '^BO_\s+\d+\s+([^:]+):', 'tokens', 'once');
    names(index) = string(token{1});
    probePath = fullfile(tempdir, sprintf('pt2000_dbc_probe_%d.dbc', index));
    fileId = fopen(probePath, 'w');
    cleanup = onCleanup(@() fclose(fileId));
    fprintf(fileId, '%s%s', header, block);
    clear cleanup
    try
        database = canDatabase(probePath); %#ok<NASGU>
        passed(index) = true;
        details(index) = "OK";
    catch exception
        details(index) = string(exception.message);
    end
    delete(probePath);
end
results = table(names, passed, details, 'VariableNames', ...
    {'Message', 'Passed', 'Details'});
disp(results);
end
