function [valid, faultBit] = validate_command_age(ageMs, timeoutMs)
%VALIDATE_COMMAND_AGE Reject stale or nonsensical command ages.
arguments
    ageMs (1,1) double
    timeoutMs (1,1) double {mustBePositive}
end
valid = isfinite(ageMs) && ageMs >= 0 && ageMs <= timeoutMs;
faultBit = uint16(~valid) * uint16(1);
end
