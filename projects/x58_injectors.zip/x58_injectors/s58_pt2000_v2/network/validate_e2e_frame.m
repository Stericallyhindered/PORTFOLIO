function [valid, reason, nextCounter] = validate_e2e_frame(payload, expectedCounter)
%VALIDATE_E2E_FRAME Validate 16-byte command payload counter and CRC.
arguments
    payload (1,16) uint8
    expectedCounter (1,1) uint8
end
counterOk = payload(15) == expectedCounter;
crcOk = payload(16) == crc8_sae_j1850(payload(1:15));
valid = counterOk && crcOk;
if ~counterOk
    reason = "COUNTER";
elseif ~crcOk
    reason = "CRC";
else
    reason = "OK";
end
nextCounter = payload(15) + uint8(1);
end
