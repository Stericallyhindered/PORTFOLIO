# CAN-FD Network Contract

- Arbitration rate: 500 kbit/s.
- Data rate: 2 Mbit/s.
- Standard 11-bit identifiers.
- Intel/little-endian signal layout.
- Rolling counter: byte 14 for 16-byte frames.
- CRC-8: byte 15 for 16-byte frames.
- Command timeout: 15 ms.
- Maximum designed utilization: 60 percent.

`pt2000_demo.dbc` is a project-defined interface for the demonstrator. It is
not an OEM BMW DBC and does not claim BMW identifiers or signal layouts.

Three command frames carry paired cylinder commands for cylinders 1-2, 3-4 and
5-6. Status, delivered-mass and diagnostic frames return PT2000/plant state to
the vehicle ECU. The heartbeat independently supervises ECU enable state.
