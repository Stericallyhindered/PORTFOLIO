function report = analyze_can_fd_load()
%ANALYZE_CAN_FD_LOAD Conservative utilization estimate for project messages.
cfg = pt2000_system_config();
frames = table( ...
    [hex2dec('100');hex2dec('180');hex2dec('181');hex2dec('280'); ...
     hex2dec('281');hex2dec('282');hex2dec('380');hex2dec('381');hex2dec('382')], ...
    [8;16;16;16;16;16;16;16;16], ...
    [100;10;10;5;5;5;10;10;100], ...
    'VariableNames', {'Id','PayloadBytes','PeriodMs'});

% Conservative split: arbitration/control at nominal rate and payload/CRC at
% data rate. Multipliers include worst-case stuffing margin without claiming
% bit-accurate controller timing.
frames.ArbitrationBits = 1.25 * 55 * ones(height(frames),1);
frames.DataBits = 1.25 * (frames.PayloadBytes * 8 + 25);
frames.FrameTimeUs = 1e6 * (frames.ArbitrationBits/cfg.can.arbitrationBitRate + ...
    frames.DataBits/cfg.can.dataBitRate);
frames.UtilizationPct = frames.FrameTimeUs ./ (frames.PeriodMs*1000) * 100;

report.frames = frames;
report.totalUtilizationPct = sum(frames.UtilizationPct);
report.limitPct = cfg.can.maxUtilizationPct;
report.passes = report.totalUtilizationPct <= report.limitPct;
assert(report.passes, 'PT2000V2:CANUtilization', ...
    'Estimated CAN-FD utilization %.1f%% exceeds %.1f%%.', ...
    report.totalUtilizationPct, report.limitPct);
end
