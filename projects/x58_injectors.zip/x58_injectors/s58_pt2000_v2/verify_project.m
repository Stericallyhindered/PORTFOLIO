function report = verify_project()
%VERIFY_PROJECT Execute tests, model build/run, live tuning, and codegen probe.
root=fileparts(mfilename('fullpath')); addpath(genpath(root));
report.timestamp=string(datetime('now'));
tests=runtests(fullfile(root,'tests'));
report.unitTestsPassed=all([tests.Passed]);
report.unitTestCount=numel(tests);
loadReport=analyze_can_fd_load();
report.canFdUtilizationPct=loadReport.totalUtilizationPct;

model='pt2000_dual_injector_demo';
build_pt2000_v2_model();
set_param(model,'StopTime','0.03');
output=sim(model);
report.modelExecuted=abs(output.tout(end)-0.03)<1e-9;

set_param(model,'StopTime','inf','SimulationCommand','start');
pause(0.25);
set_param([model '/Vehicle CAN FD Commands/RPM'],'Value','5200');
set_param([model '/Vehicle CAN FD Commands/Load pct'],'Value','105');
set_param([model '/Vehicle CAN FD Commands/Boost psi'],'Value','28');
pause(0.25);
report.liveTuningAccepted=strcmp(get_param([model '/Vehicle CAN FD Commands/RPM'],'Value'),'5200') && ...
    strcmp(get_param([model '/Vehicle CAN FD Commands/Load pct'],'Value'),'105');
set_param(model,'SimulationCommand','stop');

report.codegenAttempted=false; report.codegenPassed=false; report.codegenDetails="Not attempted";
if license('test','MATLAB_Coder')
    report.codegenAttempted=true;
    original=pwd; cleanup=onCleanup(@() cd(original));
    folder=fullfile(root,'generated','live_kernel'); if ~isfolder(folder), mkdir(folder); end
    cd(folder);
    try
        codegen('-config:lib',fullfile(root,'simulation','pt2000_live_step.m'), ...
            '-args',{zeros(1,10)},'-report');
        report.codegenPassed=true; report.codegenDetails="Static library generated";
    catch exception
        report.codegenDetails=string(exception.message);
    end
    clear cleanup
end
set_param(model,'StopTime','inf'); save_system(model); close_system(model,0);

report.passed=report.unitTestsPassed && report.modelExecuted && report.liveTuningAccepted && ...
    (~report.codegenAttempted || report.codegenPassed);
json=jsonencode(report,'PrettyPrint',true);
folder=fullfile(root,'reports'); if ~isfolder(folder), mkdir(folder); end
file=fullfile(folder,'verification_report.json'); id=fopen(file,'w');
cleanup=onCleanup(@() fclose(id)); fprintf(id,'%s\n',json); clear cleanup
fprintf('VERIFICATION passed=%d tests=%d CANFD=%.3f%% liveTuning=%d codegen=%s\n', ...
    report.passed, report.unitTestCount, report.canFdUtilizationPct, ...
    report.liveTuningAccepted, report.codegenDetails);
assert(report.passed,'PT2000V2:Verification','Project verification failed. See reports/verification_report.json.');
end
