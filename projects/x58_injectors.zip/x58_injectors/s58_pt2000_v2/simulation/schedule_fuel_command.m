function command = schedule_fuel_command(rpm, loadPct, boostPsi, lambdaTarget, cfg)
%SCHEDULE_FUEL_COMMAND Demonstrator speed/load fuel schedule with constraints.
arguments
    rpm (1,1) double {mustBeNonnegative}
    loadPct (1,1) double {mustBeInRange(loadPct,0,120)}
    boostPsi (1,1) double {mustBeInRange(boostPsi,0,40)}
    lambdaTarget (1,1) double {mustBeInRange(lambdaTarget,0.65,1.2)}
    cfg struct
end
airMassMg = 240 + 9.2*loadPct + 17.5*boostPsi;
rpmEfficiency = interp1([600 1500 3000 5000 7000 8000], ...
    [0.62 0.86 1.00 0.96 0.82 0.72], rpm, 'linear', 'extrap');
airMassMg = airMassMg * max(0.5, rpmEfficiency);
stoichAfr = 14.7;
fuelMassMg = airMassMg / (stoichAfr * lambdaTarget);
fuelMassMg = min(max(fuelMassMg, 2), 65);

referenceFlowMgPerMs = 14.5 * sqrt(cfg.injector.hydraulic.referenceRailPsi.nominal/2900);
deadTimeUs = interp1([8 10 12 14 16.5], [1150 850 650 520 430], ...
    13.5, 'linear', 'extrap');
pulseWidthUs = deadTimeUs + 1000*fuelMassMg/referenceFlowMgPerMs;

command.fuelMassMg = fuelMassMg;
command.pulseWidthUs = min(pulseWidthUs, 8000);
command.startAngleDegBTDC = min(330, 285 + 0.004*rpm - 0.18*loadPct);
command.lambdaTarget = lambdaTarget;
end
