function result = simulate_dual_pt2000(scenario)
%SIMULATE_DUAL_PT2000 Executable PT2000-style dual injector digital twin.
% This is a behavioral engineering model, not NXP microcode or OEM calibration.
if nargin == 0
    scenario = struct();
end
defaults = struct('rpm',3500,'loadPct',75,'boostPsi',20,'railPsi',2900, ...
    'lambdaTarget',0.82,'batteryV',13.5,'durationS',0.015, ...
    'channel2DelayS',0.003,'openCircuitChannel',0,'shortCircuitChannel',0);
names = fieldnames(defaults);
for index = 1:numel(names)
    if ~isfield(scenario,names{index})
        scenario.(names{index}) = defaults.(names{index});
    end
end
validateattributes(scenario.rpm,{'double'},{'scalar','nonnegative'});
validateattributes(scenario.loadPct,{'double'},{'scalar','>=',0,'<=',120});
validateattributes(scenario.boostPsi,{'double'},{'scalar','>=',0,'<=',40});
validateattributes(scenario.railPsi,{'double'},{'scalar','>=',0,'<=',6000});

root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root, 'config'));
cfg = pt2000_system_config();
command = schedule_fuel_command(scenario.rpm, scenario.loadPct, ...
    scenario.boostPsi, scenario.lambdaTarget, cfg);

dt = cfg.timing.pt2000MicrocoreStepS;
time = (0:dt:scenario.durationS)';
n = numel(time);
current = zeros(n,2); lift = zeros(n,2); velocity = zeros(n,2);
massMg = zeros(n,2); flowMgPerMs = zeros(n,2); state = zeros(n,2,'uint8');
boostV = zeros(n,1); boostV(1) = cfg.driver.boostTargetV;
eoi = false(n,2); fault = zeros(n,2,'uint16');
startS = [1e-3, 1e-3 + scenario.channel2DelayS];
stopS = startS + command.pulseWidthUs*1e-6;
inj = cfg.injector;

for k = 2:n
    channelPowerW = 0;
    for channel = 1:2
        elapsedUs = (time(k)-startS(channel))*1e6;
        enabled = time(k) >= startS(channel) && time(k) < stopS(channel);
        previousCurrent = current(k-1,channel);
        if scenario.openCircuitChannel == channel
            resistance = inj.electrical.resistanceOhm.nominal;
            fault(k,channel) = bitor(fault(k-1,channel), uint16(1));
        elseif scenario.shortCircuitChannel == channel
            resistance = 0.08;
            fault(k,channel) = bitor(fault(k-1,channel), uint16(6)); % short + protection latch
        else
            resistance = inj.electrical.resistanceOhm.nominal;
            fault(k,channel) = fault(k-1,channel);
        end

        if enabled && elapsedUs < cfg.driver.peakTimeoutUs && previousCurrent < cfg.driver.peakCurrentA
            state(k,channel) = uint8(2); % BOOST/PEAK
            appliedV = boostV(k-1);
        elseif enabled && previousCurrent < cfg.driver.holdLowA
            state(k,channel) = uint8(4); % HOLD drive
            appliedV = scenario.batteryV;
        elseif enabled && previousCurrent > cfg.driver.holdHighA
            state(k,channel) = uint8(3); % BYPASS/freewheel
            appliedV = 0;
        elseif enabled
            state(k,channel) = state(k-1,channel);
            if state(k,channel) == 4
                appliedV = scenario.batteryV;
            else
                appliedV = 0;
            end
        elseif previousCurrent > 0.05
            state(k,channel) = uint8(5); % FLYBACK
            appliedV = cfg.driver.flybackClampV;
        elseif time(k) >= stopS(channel)
            state(k,channel) = uint8(6); % EOI
            appliedV = 0;
            eoi(k,channel) = ~eoi(k-1,channel);
        else
            state(k,channel) = uint8(1); % OFF/ARMED
            appliedV = 0;
        end

        inductance = inj.electrical.inductanceClosedH.nominal + ...
            (inj.electrical.inductanceOpenH.nominal-inj.electrical.inductanceClosedH.nominal) * ...
            lift(k-1,channel)/inj.mechanical.maxLiftM.nominal;
        if scenario.openCircuitChannel == channel
            current(k,channel) = 0;
        else
            di = (appliedV - resistance*previousCurrent)/max(inductance,1e-9);
            current(k,channel) = max(0, min(cfg.driver.maxChannelCurrentA*1.2, previousCurrent + dt*di));
        end
        if current(k,channel) >= cfg.driver.maxChannelCurrentA || ...
                (scenario.shortCircuitChannel == channel && current(k,channel) >= 0.85*cfg.driver.maxChannelCurrentA)
            fault(k,channel) = bitor(fault(k,channel), uint16(4));
            current(k,channel) = min(current(k,channel), cfg.driver.maxChannelCurrentA);
        end

        pressurePa = scenario.railPsi * 6894.757;
        pressureForce = pressurePa * inj.hydraulic.effectiveAreaM2.nominal;
        magneticForce = inj.mechanical.magneticForceNPerA2.nominal * current(k,channel)^2;
        springForce = inj.mechanical.preloadN.nominal + inj.mechanical.springRateNPerM.nominal*lift(k-1,channel);
        acceleration = (magneticForce - pressureForce - springForce - ...
            inj.mechanical.dampingNsPerM.nominal*velocity(k-1,channel)) / inj.mechanical.armatureMassKg.nominal;
        velocity(k,channel) = velocity(k-1,channel) + dt*acceleration;
        lift(k,channel) = min(inj.mechanical.maxLiftM.nominal, ...
            max(0, lift(k-1,channel) + dt*velocity(k,channel)));
        if lift(k,channel)==0 || lift(k,channel)==inj.mechanical.maxLiftM.nominal
            velocity(k,channel) = 0;
        end
        openingRatio = lift(k,channel)/inj.mechanical.maxLiftM.nominal;
        massFlowKgS = inj.hydraulic.dischargeCoefficient.nominal * ...
            inj.hydraulic.effectiveAreaM2.nominal * openingRatio * ...
            sqrt(2*inj.hydraulic.fuelDensityKgPerM3.nominal*pressurePa);
        flowMgPerMs(k,channel) = massFlowKgS*1e3;
        massMg(k,channel) = massMg(k-1,channel) + flowMgPerMs(k,channel)*dt*1e3;
        channelPowerW = channelPowerW + max(appliedV,0)*current(k,channel);
    end
    sourcePowerW = scenario.batteryV*35;
    boostV(k) = boostV(k-1) + dt*((cfg.driver.boostTargetV-boostV(k-1))/0.0015 + ...
        (sourcePowerW-channelPowerW)/max(boostV(k-1)*0.0047,1));
    boostV(k) = min(cfg.driver.boostMaxV, max(0, boostV(k)));
end

result.meta.model = "PT2000-style dual-channel behavioral digital twin";
result.meta.injectorProvenance = inj.meta.provenance;
result.meta.releaseApproved = inj.meta.releaseApproved;
result.scenario = scenario;
result.command = command;
result.timeseries = timetable(seconds(time), current(:,1), current(:,2), ...
    lift(:,1)*1e6, lift(:,2)*1e6, flowMgPerMs(:,1), flowMgPerMs(:,2), ...
    massMg(:,1), massMg(:,2), boostV, state(:,1), state(:,2), fault(:,1), fault(:,2), ...
    'VariableNames', {'Current1_A','Current2_A','Lift1_um','Lift2_um', ...
    'Flow1_mg_ms','Flow2_mg_ms','Mass1_mg','Mass2_mg','BoostBus_V', ...
    'State1','State2','Fault1','Fault2'});
result.summary = table((1:2)', repmat(command.fuelMassMg,2,1), massMg(end,:)', ...
    max(current)', max(lift)'*1e6, fault(end,:)', ...
    'VariableNames', {'Channel','RequestedMass_mg','DeliveredMass_mg', ...
    'PeakCurrent_A','PeakLift_um','FaultBits'});
end
