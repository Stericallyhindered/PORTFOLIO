function y = pt2000_live_step(u)
%#codegen
%PT2000_LIVE_STEP Fixed-step dual-channel live demonstrator kernel.
% u: rpm, load%, boost target psi, rail psi, lambda, battery V, open ch,
%    short ch, enable, reset. y contract is documented in docs/signal_dictionary.md.
persistent i lift velocity mass phase state boostBus fault actualBoostPsi lastEventIndex activeCylinder
if isempty(i) || u(10) > 0.5
    i = zeros(1,6); lift = zeros(1,6); velocity = zeros(1,6);
    mass = zeros(1,6); phase = 0; state = zeros(1,6);
    boostBus = 65; fault = zeros(1,6); actualBoostPsi = min(40,max(0,u(3)));
    lastEventIndex = -1; activeCylinder = 1;
end

dt = 1e-5; rpm = max(0,u(1)); loadPct = min(120,max(0,u(2)));
boostPsi = min(40,max(0,u(3))); railPsi = min(6000,max(0,u(4)));
lambda = min(1.2,max(0.65,u(5))); battery = min(16.5,max(8,u(6)));

spoolRatePsiPerS = 16 + 0.004*rpm + 0.18*loadPct;
boostError = boostPsi - actualBoostPsi;
actualBoostPsi = actualBoostPsi + dt * max(-spoolRatePsiPerS, min(spoolRatePsiPerS, boostError/0.18));
actualBoostPsi = min(42, max(0, actualBoostPsi));

airMassMg = (240 + 9.2*loadPct + 17.5*actualBoostPsi) * min(1,max(0.5,0.62+rpm/9000));
requestMg = min(120,max(2,airMassMg/(14.7*lambda)));
pulseUs = min(8000,650 + 1000*requestMg/(14.5*sqrt(max(railPsi,1)/2900)));
cycleS = 120/max(rpm,100);
injectionEventsPerSec = rpm/120*6;
phase = mod(phase + dt/cycleS,1);
crankAngleDeg = phase*720;
firingOrder = [1 5 3 6 2 4];
eventSpacingDeg = 120;
soiBtdcDeg = min(320,max(260,300 - 0.18*loadPct + 0.35*boostPsi));
eventIndex = floor(crankAngleDeg/eventSpacingDeg);
if eventIndex ~= lastEventIndex
    activeCylinder = firingOrder(mod(eventIndex,6)+1);
    lastEventIndex = eventIndex;
end
eventCrankDeg = crankAngleDeg - eventIndex*eventSpacingDeg;
startDeg = max(0,min(115,eventSpacingDeg - soiBtdcDeg + 360));
durationDeg = min(45,max(2,pulseUs*1e-6/cycleS*720));
eventStartDeg = zeros(1,6);
for n = 1:6
    eventStartDeg(firingOrder(n)) = (n-1)*eventSpacingDeg + startDeg;
end

R = 1.25; L0 = 280e-6; L1 = 360e-6; maxLift = 45e-6;
armatureMass = 1.5e-3; spring = 2e4; damping = 2.5;
preload = 18; magneticK = 0.55; area = 9.5e-7; rho = 745; cd = 0.72;
power = 0;
for channel = 1:6
    localDeg = mod(crankAngleDeg - eventStartDeg(channel), 720);
    enabled = u(9)>0.5 && localDeg < durationDeg;
    elapsedUs = localDeg/720*cycleS*1e6;
    openFault = round(u(7)) == channel;
    shortFault = round(u(8)) == channel;
    if openFault, fault(channel)=bitor(uint16(fault(channel)),uint16(1)); end
    if shortFault, fault(channel)=bitor(uint16(fault(channel)),uint16(6)); end
    if enabled && elapsedUs < 550 && i(channel) < 11
        state(channel)=2; applied=boostBus;
    elseif enabled && i(channel)<3.4
        state(channel)=4; applied=battery;
    elseif enabled && i(channel)>4.2
        state(channel)=3; applied=0;
    elseif enabled
        if state(channel)==4, applied=battery; else, applied=0; end
    elseif i(channel)>0.05
        state(channel)=5; applied=-55;
    else
        state(channel)=6; applied=0;
    end
    resistance = R;
    if shortFault, resistance=0.08; end
    inductance = L0+(L1-L0)*lift(channel)/maxLift;
    if openFault
        i(channel)=0;
    else
        i(channel)=min(18,max(0,i(channel)+dt*(applied-resistance*i(channel))/inductance));
    end
    pressure = railPsi*6894.757;
    accel = (magneticK*i(channel)^2-pressure*area-preload-spring*lift(channel)-damping*velocity(channel))/armatureMass;
    velocity(channel)=velocity(channel)+dt*accel;
    lift(channel)=min(maxLift,max(0,lift(channel)+dt*velocity(channel)));
    if lift(channel)<=0 || lift(channel)>=maxLift, velocity(channel)=0; end
    flow = cd*area*(lift(channel)/maxLift)*sqrt(2*rho*pressure)*1e3;
    if enabled || lift(channel)>0, mass(channel)=mass(channel)+flow*dt*1e3; end
    if ~enabled && i(channel)<0.05 && lift(channel)==0 && localDeg>144
        mass(channel)=0;
    end
    power=power+max(applied,0)*i(channel);
end
boostBus=min(72,max(0,boostBus+dt*((65-boostBus)/0.0015+(battery*35-power)/max(boostBus*0.0047,1))));
flowVec = zeros(1,6);
for channel = 1:6
    flowVec(channel)=cd*area*(lift(channel)/maxLift)*sqrt(2*rho*railPsi*6894.757)*1e3;
end
flow1=flowVec(1);
flow2=flowVec(2);
y=[requestMg pulseUs/1000 i(1) i(2) lift(1)*1e6 lift(2)*1e6 ...
   flow1 flow2 mass(1) mass(2) state(1) state(2) boostBus double(fault(1)) double(fault(2)) phase ...
   boostPsi actualBoostPsi injectionEventsPerSec cycleS*1000 crankAngleDeg activeCylinder soiBtdcDeg durationDeg eventCrankDeg ...
   i(3) i(4) i(5) i(6) mass(3) mass(4) mass(5) mass(6) state(3) state(4) state(5) state(6)];
end
