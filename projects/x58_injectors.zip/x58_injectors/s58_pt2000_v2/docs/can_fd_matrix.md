# CAN-FD network matrix

Nominal arbitration rate is 500 kbit/s. Data phase is 2 Mbit/s with bit-rate
switching. The sample point target is 80%. The conservative calculated load is
23.739%, below the project ceiling of 60%.

| ID | Message | Tx | Bytes | Period | Protection | Purpose |
|---:|---|---|---:|---:|---|---|
| 0x100 | NETWORK_HEARTBEAT | Vehicle ECU | 8 | 100 ms | Counter + CRC-8 | Enable and network state |
| 0x180 | ENGINE_STATE | Vehicle ECU | 16 | 10 ms | Counter + CRC-8 | RPM, load, torque, IAT, battery |
| 0x181 | AIR_FUEL_STATE | Vehicle ECU | 16 | 10 ms | Counter + CRC-8 | Boost, lambda, rail pressure |
| 0x280 | INJECTOR_COMMAND_12 | Vehicle ECU | 16 | 5 ms | Counter + CRC-8 | Cylinders 1 and 2 command |
| 0x281 | INJECTOR_COMMAND_34 | Vehicle ECU | 16 | 5 ms | Counter + CRC-8 | Cylinders 3 and 4 command |
| 0x282 | INJECTOR_COMMAND_56 | Vehicle ECU | 16 | 5 ms | Counter + CRC-8 | Cylinders 5 and 6 command |
| 0x380 | DRIVER_STATUS | Injector MCU | 16 | 10 ms | Counter + CRC-8 | Current, state, boost bus, faults |
| 0x381 | DRIVER_DELIVERY | Injector MCU | 16 | 10 ms | Counter + CRC-8 | Requested/delivered mass and EOI |
| 0x382 | DRIVER_DIAGNOSTICS | Injector MCU | 16 | 100 ms | Counter + CRC-8 | Channel, SPI, CAN, reset diagnostics |

CRC uses CRC-8/SAE-J1850: polynomial `0x1D`, initialization `0xFF`, final XOR
`0xFF`, no reflection. For 16-byte frames, byte 14 (zero-based) is the alive
counter and byte 15 is CRC over bytes 0 through 14. A command is rejected on
CRC mismatch, unexpected counter, or age over 15 ms. IDs and scaling are
project-specific and are not BMW/OEM network data.
