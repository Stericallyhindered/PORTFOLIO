# Verification matrix

| Requirement | Evidence | Current result |
|---|---|---|
| CAN database and DLC | `testDatabaseAndFdLengths` | Pass |
| CRC corruption rejection | `testCrcKnownCheckAndBitFlip` | Pass |
| Counter rejection | `testCounterRejection` | Pass |
| Bus utilization below 60% | `testLoadBudget` | Pass, 23.739% |
| Two physical injector events | `testNominalDualInjection` | Pass |
| Fuel rises with load/boost | `testScheduleRespondsToLoadAndBoost` | Pass |
| Open-load diagnostic | `testOpenCircuitDiagnostic` | Pass |
| Short/protection latch | `testShortCircuitProtection` | Pass |
| Generated Simulink execution | `verify_project` | Pass when report says PASS |
| Live constant tuning | `verify_project` | Pass when report says PASS |
| C/C++ code generation | `verify_project` | Conditional on installed license |

## Required before hardware release

- Measured injector R/L versus temperature and lift.
- Current-to-force and lift-to-effective-flow-area characterization.
- Minimum pulse, opening/closing delay, bounce, and EOI correlation.
- MOSFET SOA, gate-drive timing, shunt/filter tolerance, boost energy budget.
- Worst-case tolerance and Monte Carlo analysis.
- Processor-in-loop, HIL, fault insertion, thermal, EMC, transient, and vehicle tests.
- Safety analysis, diagnostics coverage, watchdog strategy, and independent review.
