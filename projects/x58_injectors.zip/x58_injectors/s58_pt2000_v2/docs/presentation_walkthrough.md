# Presentation walkthrough

1. Open `pt2000_dual_injector_demo.slx` with `open_pt2000_demo`.
2. On the top level, explain the data path left to right: local engine
   sensors and CAN-FD supervisory commands, E2E/plausibility validation, fuel
   and crank-angle scheduling, MCU SPI/START control, PT2000 device and dual
   power stage, decoded engineering signals, persistent logging.
3. Open **Operator Dashboard** and press Run. The model runs continuously.
4. Increase load and boost. Show scheduled fuel mass and pulse width rising.
5. Point out crank angle, active cylinder, SOI BTDC, injection duration, and
   injection event rate. Explain that crank/cam are local ECU sensor inputs,
   while CAN-FD carries supervisory requests such as torque/load, boost target,
   enable, diagnostics, and status.
6. Show both current traces progress through BOOST/PEAK, BYPASS, HOLD,
   FLYBACK, and EOI while lift, flow, and integrated mass respond.
7. Set **Open fault ch** to 1. Channel 1 current and delivery collapse and fault
   bit 0 latches while channel 2 continues.
8. Reset, then set **Short fault ch** to 2. Show short/protection bits 1 and 2.
9. Stop. Open `logs/latest_run.log` and `logs/latest_run.mldatx` to demonstrate
   reproducibility and SDI trace retention.
10. State the engineering boundary plainly: PT2000 behavior and two physical
   channels are modeled; injector constants are bounded estimates pending bench
   characterization; this is presentation-ready and production-structured, not
   released vehicle hardware.

Suggested phrasing: "I separated time-critical engine position sensing from
network commands. Crank/cam phase stays local to the ECU because injection
scheduling is crank-angle based, while CAN-FD carries supervisory requests,
diagnostics, and status. The PT2000 receives scheduled channel events and
current-control targets, not raw engine-load inputs."
