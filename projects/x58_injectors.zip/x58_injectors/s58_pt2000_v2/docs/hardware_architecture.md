# Hardware architecture and wiring intent

This document is an engineering demonstrator wiring contract, not a released
PCB schematic. Component values, MOSFET selection, connector pinout, creepage,
EMC filtering, thermal design, and injector characterization require bench and
vehicle validation before hardware release.

```mermaid
flowchart LR
  SENS["Local engine sensors: crank, cam, MAP/boost, rail pressure, lambda, battery"] --> ECU["Engine ECU / safety MCU"]
  NET["Vehicle CAN-FD: torque/load request, boost target, lambda target, enable, diagnostics"] -->|"CANH, CANL; 500 kbit/s arb, 2 Mbit/s data"| XCVR["Automotive CAN-FD transceiver"]
  XCVR --> ECU
  ECU -->|"SPI 5 MHz, mode 1: SCLK, MOSI, MISO, CS_n"| PT["NXP PT2000"]
  ECU -->|"START1..START6, RESET_n, IRQ_n"| PT
  BAT["12 V battery"] --> PROT["Fuse, reverse battery, TVS, EMI filter"]
  PROT --> BOOST["65 V boost converter and reservoir"]
  PROT --> LV["5 V / 3.3 V supplies"]
  LV --> ECU
  LV --> PT
  BOOST --> HS1["External high-side MOSFET stage CH1"]
  BOOST --> HS2["External high-side MOSFET stage CH2"]
  PT -->|"HS gate predrive"| HS1
  PT -->|"LS gate predrive"| LS1["External low-side MOSFET stage CH1"]
  PT -->|"HS gate predrive"| HS2
  PT -->|"LS gate predrive"| LS2["External low-side MOSFET stage CH2"]
  HS1 --> A1["Injector 1 lead A"]
  B1["Injector 1 lead B"] --> LS1
  HS2 --> A2["Injector 2 lead A"]
  B2["Injector 2 lead B"] --> LS2
  A1 --- INJ1["Two-wire GDI injector 1 coil"] --- B1
  A2 --- INJ2["Two-wire GDI injector 2 coil"] --- B2
  LS1 --> SH1["Kelvin current shunt CH1"] --> PGND["Power ground star point"]
  LS2 --> SH2["Kelvin current shunt CH2"] --> PGND
  SH1 -->|"Differential sense"| PT
  SH2 -->|"Differential sense"| PT
  A1 --> CL1["Bidirectional flyback clamp CH1"] --> BOOST
  A2 --> CL2["Bidirectional flyback clamp CH2"] --> BOOST
  PT -->|"EOI, short/open, UV/OV, overtemp"| ECU
  ECU -->|"0x380..0x382 status/diagnostics"| XCVR
```

## Signal boundary

Crank and cam position are local ECU sensor inputs, not normal CAN-FD command
signals. Injection scheduling is crank-angle based and needs deterministic,
low-latency position information. In the Simulink demonstrator, the command
source block still carries some sensor-like values for live tuning, but the
presentation boundary is:

- Local engine sensors: crank angle, cam sync, derived RPM, MAP/actual boost,
  rail pressure, lambda, battery voltage, temperatures.
- CAN-FD inputs: torque/load request, boost target, lambda target, enable,
  diagnostic command, fault reset, calibration/mode selection.
- PT2000 interface: SPI configuration, START events, channel select,
  peak/hold/flyback targets, fault clear, and diagnostic reads.

## Grounding and connector rules

- Keep logic ground and power ground separate until a controlled star point.
- Route each shunt as a Kelvin pair to the PT2000 current-sense input network.
- Route injector A/B as a tightly coupled pair; neither injector lead is a
  permanent chassis ground.
- Put gate resistors and gate-source clamps adjacent to external MOSFETs.
- Place the boost reservoir, high-side devices, flyback path, and injector
  connector to minimize the high-di/dt loop.
- Protect every off-board line for ISO 7637-2/ISO 16750 transients as required
  by the target vehicle program; ratings are not selected in this demonstrator.
- Six command channels are represented. Two channels are fully simulated in
  parallel; production six-cylinder hardware requires validated resource and
  concurrency allocation across PT2000 high-side and low-side predrivers.

## PT2000 abstraction boundary

The model represents the documented PT2000 architecture: MCU SPI interface,
START inputs, microcore-controlled peak/hold/flyback sequencing, external gate
predrivers, current measurement, EOI, and diagnostics. It does not reproduce
NXP proprietary internal analog circuitry or claim to be PT2000 firmware.

Primary references: [NXP MC33PT2000 data sheet](https://www.nxp.com/docs/en/data-sheet/MC33PT2000.pdf),
[NXP PT2000 programming guide](https://community.nxp.com/pwmxy87654/attachments/pwmxy87654/analog-drivers/702/1/PT2000SWUG.pdf),
and the [NXP six-cylinder evaluation platform](https://www.nxp.com/design/development-boards/automotive-development-platforms/s32k-mcu-platforms/pt2000-3-4-6-cylinders-engine-evaluation-board%3AFRDMPKPT2000EVM).
