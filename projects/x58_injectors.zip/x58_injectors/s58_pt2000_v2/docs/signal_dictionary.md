# Live signal dictionary

The `pt2000_live_step` kernel accepts the dashboard command vector and emits a
25-element two-channel driver vector. Operator values use PSI; pressure is converted to pascals
inside the hydraulic plant.

| Input | Meaning | Unit |
|---:|---|---|
| 1 | Engine speed command | rpm |
| 2 | Engine load command | percent |
| 3 | Manifold boost command | psi gauge |
| 4 | Fuel rail pressure command | psi |
| 5 | Lambda target | ratio |
| 6 | Battery voltage | V |
| 7 | Open-circuit fault channel, 0/1/2 | enum |
| 8 | Short-circuit fault channel, 0/1/2 | enum |
| 9 | Driver enable | Boolean |
| 10 | State reset | Boolean |
| 11 | Demo speed scale for slow-motion presentation | 0.5-1.0 |

| Output | Meaning | Unit |
|---:|---|---|
| 1 | Scheduled fuel mass | mg/event |
| 2 | Scheduled pulse width | ms |
| 3-4 | Channel coil current | A |
| 5-6 | Channel armature lift | um |
| 7-8 | Channel fuel flow | mg/ms |
| 9-10 | Integrated event mass | mg |
| 11-12 | PT2000 state | enum |
| 13 | Boost bus voltage | V |
| 14-15 | Latched channel fault bits | bitfield |
| 16 | 720-degree engine-cycle phase | ratio |
| 17 | Boost target command | psi gauge |
| 18 | Simulated actual boost | psi gauge |
| 19 | Six-cylinder injection event rate | events/s |
| 20 | Four-stroke engine cycle duration | ms |
| 21 | Crank angle in current 720-degree cycle | crank deg |
| 22 | Active cylinder from firing order `[1 5 3 6 2 4]` | cylinder |
| 23 | Start-of-injection timing before TDC | crank deg BTDC |
| 24 | Injection pulse duration converted to crank angle | crank deg |
| 25 | Crank angle since the start of current 120-degree firing slot | crank deg |
The dashboard graphs are intentionally two-channel scope views: Ch1/Ch2 current
and Ch1/Ch2 fuel flow plus delivered mass. They are not six-cylinder overview
plots, because the purpose is to inspect the driver waveform shape.

State values: 1 OFF/ARMED, 2 BOOST/PEAK, 3 BYPASS/FREEWHEEL, 4 HOLD,
5 FLYBACK, 6 EOI. Fault bits: bit 0 open load, bit 1 short load, bit 2
overcurrent/protection latch.
