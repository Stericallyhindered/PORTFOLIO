function [memory, readData, status] = pt2000_spi_transaction(memory, controlWord, writeData)
%PT2000_SPI_TRANSACTION Behavioral PT2000 SPI burst read/write transaction.
arguments
    memory (1024,1) uint16
    controlWord (1,1) uint16
    writeData (1,:) uint16 = uint16.empty(1,0)
end
isRead = bitget(controlWord,16) ~= 0;
offset = double(bitand(bitshift(controlWord,-5),uint16(1023)));
count = double(bitand(controlWord,uint16(31)));
status = uint16(0); readData = zeros(1,count,'uint16');
if count < 1 || offset+count > numel(memory)
    status = bitor(status,uint16(1));
    return
end
addresses = offset+(1:count);
if isRead
    readData = memory(addresses).';
elseif numel(writeData) ~= count
    status = bitor(status,uint16(2));
else
    memory(addresses) = writeData;
end
end
