function word = pt2000_spi_control_word(isRead, offset, operationCount)
%PT2000_SPI_CONTROL_WORD Encode the documented PT2000 16-bit SPI control word.
arguments
    isRead (1,1) logical
    offset (1,1) double {mustBeInteger,mustBeInRange(offset,0,1023)}
    operationCount (1,1) double {mustBeInteger,mustBeInRange(operationCount,1,31)}
end
word = bitor(bitshift(uint16(isRead),15), ...
    bitor(bitshift(uint16(offset),5),uint16(operationCount)));
end
