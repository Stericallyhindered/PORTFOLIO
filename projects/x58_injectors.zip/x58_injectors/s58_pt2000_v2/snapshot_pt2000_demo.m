function snapshot_pt2000_demo()
%SNAPSHOT_PT2000_DEMO Print the latest PT2000 demo signals for copy/paste.
model = 'pt2000_dual_injector_demo';
if ~bdIsLoaded(model)
    load_system(model);
end

if ~strcmp(get_param(model, 'SimulationStatus'), 'stopped')
    set_param(model, 'SimulationCommand', 'pause');
end

vars = evalin('base', 'whos');
names = string({vars.name});
signals = [
    "PT2K_3", "Current Ch1 A"
    "PT2K_4", "Current Ch2 A"
    "PT2K_5", "Lift Ch1 um"
    "PT2K_6", "Lift Ch2 um"
    "PT2K_7", "Flow Ch1 mg_per_ms"
    "PT2K_8", "Flow Ch2 mg_per_ms"
    "PT2K_9", "Mass Ch1 mg"
    "PT2K_10", "Mass Ch2 mg"
    "PT2K_13", "Boost Bus V"
    "PT2K_14", "Fault Ch1 bits"
    "PT2K_15", "Fault Ch2 bits"
];

fprintf('\nPT2000 DEMO SNAPSHOT %s\n', datestr(now, 31));
fprintf('Simulation status: %s\n', get_param(model, 'SimulationStatus'));
fprintf('--------------------------------------------------\n');
for k = 1:size(signals, 1)
    variableName = signals(k, 1);
    label = signals(k, 2);
    if any(names == variableName)
        ts = evalin('base', variableName);
        if isa(ts, 'timeseries') && ~isempty(ts.Data)
            value = squeeze(ts.Data(end));
            time = ts.Time(end);
            fprintf('%-20s %12.4f at t=%8.4f s\n', label, value, time);
        else
            fprintf('%-20s unavailable: variable exists but has no samples\n', label);
        end
    else
        fprintf('%-20s unavailable: %s not in base workspace yet\n', label, variableName);
    end
end
fprintf('--------------------------------------------------\n\n');
end
