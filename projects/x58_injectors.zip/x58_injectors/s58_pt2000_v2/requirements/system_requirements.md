# System Requirements

| ID | Requirement | Verification |
|---|---|---|
| SYS-001 | The architecture shall support six injector commands and simulate two independent physical channels concurrently. | MIL scenario |
| SYS-002 | Operator boost and rail-pressure interfaces shall use psi; internal pressure calculations shall use SI-derived units with explicit conversion blocks. | Model inspection, unit test |
| SYS-003 | The controller shall reject stale, range-invalid, counter-invalid or CRC-invalid vehicle commands. | Fault injection |
| SYS-004 | The MCU/PT2000 boundary shall expose SPI configuration/status transactions and independent START triggers. | Interface test |
| SYS-005 | Each injector channel shall implement OFF, BOOST, PEAK, BYPASS, HOLD, FLYBACK, EOI and FAULT behavior. | State coverage |
| SYS-006 | The plant shall expose both injector terminal voltages, differential voltage, coil current, armature position, instantaneous flow and integrated delivered mass. | Signal inspection |
| SYS-007 | The model shall detect open load, short to battery, short to ground, overcurrent, boost undervoltage, VDS fault, EOI timeout and stale command. | Fault matrix |
| SYS-008 | Every simulation shall create a text diagnostic log and Simulation Data Inspector archive. | Automated test |
| SYS-009 | Dashboard controls shall tune parameters while simulation is running and shall contain no executable control logic. | Live-tuning test, model inspection |
| SYS-010 | Injector-specific parameters shall include nominal, minimum, maximum, unit and provenance fields. | Schema test |
| SYS-011 | Code generation shall include only the MCU controller and hardware abstraction interfaces. | Generated-code inspection |
| SYS-012 | The project shall not identify estimated calibration as measured S58 or OEM BMW data. | Document review |
