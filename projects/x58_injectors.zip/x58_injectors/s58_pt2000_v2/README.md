# PT2000 Dual-Channel GDI Driver Simulator V2

This is the clean model-based-development replacement for the exploratory
`s58_injector_driver` prototype. It targets a six-channel-capable PT2000
architecture and fully simulates two concurrent injector channels. Injector
parameters are replaceable because the exact S58 injector characterization is
not yet available.

## Product boundary

The project models:

- CAN-FD vehicle interface, message timing, scaling, counters, CRC and timeout.
- MCU crank-angle scheduling, command validation and PT2000 SPI service.
- PT2000 configuration RAM, code RAM behavior, START inputs, microcore state,
  current thresholds, EOI processing and diagnostic reporting.
- Boost converter, external high-side/low-side MOSFET stages, current shunts,
  differential injector voltage and flyback paths.
- Two independent injector electrical, armature and hydraulic plants.
- Fault injection, persistent logs, Simulation Data Inspector logging and tests.

The exact injector plant is not claimed as S58 production calibration until
measured data replaces the bounded placeholder parameter set.

## Non-negotiable rules

1. Dashboard blocks never implement control or plant behavior.
2. Every signal has a unit, range, owner and invalid-value behavior.
3. Estimated parameters include provenance and uncertainty bounds.
4. Controller and plant execute at explicit fixed sample times.
5. All faults latch, report and recover according to a testable requirement.
6. Generated code excludes dashboards, scopes and physical plant models.
7. No artifact is called production-released without target hardware, HIL,
   thermal, EMC and safety evidence.

## Delivered artifacts

- `pt2000_dual_injector_demo.slx` - integrated MIL model and native dashboard.
- `simulation/pt2000_live_step.m` - code-generatable live driver/plant kernel.
- `simulation/simulate_dual_pt2000.m` - high-resolution offline digital twin.
- `pt2000/` - documented 16-bit SPI control-word and burst-memory behavior.
- `network/pt2000_demo.dbc` - project CAN-FD interface, not an OEM BMW DBC.
- `generated/live_kernel/` - generated C static library and code report.
- `docs/` - wiring, signal, CAN-FD, verification, and presentation material.
- `tests/` - requirements-linked nominal, boundary, transport, and fault tests.

## Run the demonstrator

From the MATLAB command window:

```matlab
cd('C:\Users\h4zy\Documents\Codex\2026-07-16\okay\work\s58_pt2000_v2')
verify_project
open_pt2000_demo
```

`verify_project` rebuilds the generated model, runs the automated network and
plant tests, executes the model, changes RPM/load/boost while it is running,
and attempts C static-library generation when MATLAB Coder is licensed.

The generated presentation model is `pt2000_dual_injector_demo.slx`. It has a
native Simulink Operator Dashboard with real tunable command parameters and
displays/scopes bound to the live PT2000-style electrical, mechanical, and
hydraulic plant outputs.

## Reference basis

- NXP MC33PT2000 data sheet, Rev. 13, May 2022.
- NXP PT2000 programming guide and instruction set, Rev. 1.
- NXP AN5186 PT2000 diagnostics.
- NXP AN5187 three-injector freewheeling and DC/DC example.
- NXP FRDMPKPT2000EVM six-cylinder evaluation design and example software.
