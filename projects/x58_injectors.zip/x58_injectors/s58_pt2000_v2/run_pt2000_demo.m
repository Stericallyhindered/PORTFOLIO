function run_pt2000_demo()
%RUN_PT2000_DEMO Open the PT2000 V2 Simulink demo and start live simulation.
root = fileparts(mfilename('fullpath'));
cd(root);
addpath(genpath(root));

model = 'pt2000_dual_injector_demo';
modelFile = fullfile(root, model + ".slx");

builderFile = fullfile(root, "build_pt2000_v2_model.m");
kernelFile = fullfile(root, "simulation", "pt2000_live_step.m");
needsBuild = ~isfile(modelFile);
if ~needsBuild
    modelInfo = dir(modelFile);
    builderInfo = dir(builderFile);
    kernelInfo = dir(kernelFile);
    needsBuild = builderInfo.datenum > modelInfo.datenum || kernelInfo.datenum > modelInfo.datenum;
end

if needsBuild
    build_pt2000_v2_model();
end

load_system(model);
set_param(model, 'StopTime', 'inf');
set_param(model, 'SimulationMode', 'normal');
set_param(model, 'FastRestart', 'off');
try
    set_param(model, 'EnablePacing', 'on', 'PacingRate', '1');
catch
end

open_system(model);
set_param(model, 'ZoomFactor', 'FitSystem');

dashboard = model + "/Operator Dashboard";
if ~isempty(find_system(model, 'SearchDepth', 1, 'Name', 'Operator Dashboard'))
    open_system(dashboard);
    set_param(dashboard, 'ZoomFactor', 'FitSystem');
end

set_param(model, 'SimulationCommand', 'start');
drawnow;

fprintf('\nPT2000 V2 demo is open and %s.\n', get_param(model, 'SimulationStatus'));
fprintf('Use the Operator Dashboard sliders while it is running.\n\n');
end
