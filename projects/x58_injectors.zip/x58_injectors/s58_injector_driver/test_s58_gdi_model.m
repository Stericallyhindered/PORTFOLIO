function tests = test_s58_gdi_model
tests = functiontests(localfunctions);
end

function testFuelRisesWithLoad(testCase)
cal = s58_gdi_calibration();
base = defaultInput();
base.loadPct = 30;
low = s58_gdi_operating_point(base, cal);
base.loadPct = 100;
base.boostActualKPa = 150;
high = s58_gdi_operating_point(base, cal);
verifyGreaterThan(testCase, high.fuelRequestMg, low.fuelRequestMg);
end

function testCanCrcAndCounter(testCase)
cal = s58_gdi_calibration();
p = s58_gdi_operating_point(defaultInput(), cal);
p.counter = 257;
frame = s58_gdi_can_codec("fuel-command", p, cal);
verifyTrue(testCase, frame.crcValid);
verifyEqual(testCase, frame.counter, 1);
verifyEqual(testCase, frame.id, cal.can.fuelCommandId);
end

function testInjectorEventIsPhysical(testCase)
cal = s58_gdi_calibration();
p = s58_gdi_operating_point(defaultInput(), cal);
p.batteryV = 13.5;
p.coilTempC = 80;
event = s58_gdi_injector_event(p, cal);
verifyGreaterThan(testCase, event.peakCurrentA, cal.injector.openCurrentA);
verifyGreaterThan(testCase, event.deliveredMg, 0);
verifyGreaterThanOrEqual(testCase, min(event.currentA), 0);
end

function in = defaultInput()
in = struct("rpm", 4000, "loadPct", 70, "boostTargetKPa", 120, ...
    "boostActualKPa", 110, "iatC", 35, "batteryV", 13.5, ...
    "measuredLambda", 0.9, "railActualBar", 250);
end
