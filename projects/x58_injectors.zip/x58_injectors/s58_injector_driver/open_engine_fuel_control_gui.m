function open_engine_fuel_control_gui()
%OPEN_ENGINE_FUEL_CONTROL_GUI Interactive engine/fuel/injector presentation model.

cfg = localDefaultConfig();

fig = uifigure("Name", "S58 Fuel Injector Control Simulator", ...
    "Position", [80 60 1380 820], ...
    "Color", [0.98 0.98 0.97]);

main = uigridlayout(fig, [2 2]);
main.RowHeight = {140, "1x"};
main.ColumnWidth = {360, "1x"};
main.Padding = [12 12 12 12];
main.RowSpacing = 10;
main.ColumnSpacing = 12;

titlePanel = uipanel(main, "Title", "Operating Point");
titlePanel.Layout.Row = 1;
titlePanel.Layout.Column = [1 2];
titleGrid = uigridlayout(titlePanel, [1 6]);
titleGrid.ColumnWidth = repmat({"1x"}, 1, 6);

stats = gobjects(1, 6);
statNames = ["Pulse Width", "Target Lambda", "Fuel / Cyl", "Air / Cyl", "Window Used", "Boost Error"];
for i = 1:6
    stats(i) = uilabel(titleGrid, "Text", statNames(i), ...
        "HorizontalAlignment", "center", ...
        "FontWeight", "bold", ...
        "FontSize", 13);
end

controlsPanel = uipanel(main, "Title", "Change Engine Parameters");
controlsPanel.Layout.Row = 2;
controlsPanel.Layout.Column = 1;
controls = uigridlayout(controlsPanel, [15 2]);
controls.RowHeight = repmat({34}, 1, 15);
controls.ColumnWidth = {155, "1x"};

plotPanel = uipanel(main, "Title", "Live Simulation");
plotPanel.Layout.Row = 2;
plotPanel.Layout.Column = 2;
plots = uigridlayout(plotPanel, [2 2]);
plots.RowHeight = {"1x", "1x"};
plots.ColumnWidth = {"1x", "1x"};

axFuel = uiaxes(plots);
title(axFuel, "Fuel Command and Headroom");
grid(axFuel, "on");
axTrace = uiaxes(plots);
title(axTrace, "Injector Current and Differential Voltage");
grid(axTrace, "on");
axLambda = uiaxes(plots);
title(axLambda, "Lambda / Boost Control");
grid(axLambda, "on");
axMap = uiaxes(plots);
title(axMap, "Operating Point Map");
grid(axMap, "on");

widgets.rpm = addSlider(controls, "RPM", 800, 7600, cfg.engine.rpm, "%.0f");
widgets.load = addSlider(controls, "Load %", 5, 120, cfg.engine.load_pct, "%.0f");
widgets.boostTarget = addSlider(controls, "Boost Target kPa", 0, 230, cfg.engine.boost_target_kpa, "%.0f");
widgets.boostActual = addSlider(controls, "Actual Boost kPa", 0, 230, cfg.engine.boost_actual_kpa, "%.0f");
widgets.iat = addSlider(controls, "IAT C", -10, 80, cfg.engine.iat_c, "%.0f");
widgets.lambdaBase = addSlider(controls, "Base Lambda", 0.76, 1.05, cfg.fuel.lambda_base, "%.2f");
widgets.lambdaMeasured = addSlider(controls, "Measured Lambda", 0.70, 1.20, cfg.fuel.lambda_measured, "%.2f");
widgets.fuelPressure = addSlider(controls, "Fuel Pressure bar", 80, 350, cfg.fuel.pressure_bar, "%.0f");
widgets.injectorFlow = addSlider(controls, "Injector cc/min", 400, 1500, cfg.injector.flow_cc_min, "%.0f");
widgets.deadtime = addSlider(controls, "Deadtime ms", 0.05, 1.20, cfg.injector.deadtime_ms, "%.2f");
widgets.windowDeg = addSlider(controls, "Inject Window deg", 90, 520, cfg.injector.injection_window_deg, "%.0f");
widgets.vBoost = addSlider(controls, "Driver Boost V", 35, 90, cfg.electrical.v_boost, "%.0f");
widgets.iPeak = addSlider(controls, "Peak Current A", 5, 18, cfg.electrical.i_peak_a, "%.1f");
widgets.iHoldLow = addSlider(controls, "Hold Low A", 1.5, 6.5, cfg.electrical.i_hold_low_a, "%.1f");
widgets.iHoldHigh = addSlider(controls, "Hold High A", 2.0, 7.5, cfg.electrical.i_hold_high_a, "%.1f");

widgetFields = fieldnames(widgets);
for i = 1:numel(widgetFields)
    widgets.(widgetFields{i}).ValueChangingFcn = @(src, event) update(event.Value, src, false);
    widgets.(widgetFields{i}).ValueChangedFcn = @(src, event) update(event.Value, src, true);
end

update([], [], true);

    function slider = addSlider(parent, labelText, minValue, maxValue, value, fmt)
        label = uilabel(parent, "Text", labelText);
        label.FontWeight = "bold";
        slider = uislider(parent, "Limits", [minValue maxValue], "Value", value);
        slider.MajorTicks = [];
        slider.UserData.Format = fmt;
        slider.UserData.Label = label;
        slider.UserData.LabelText = labelText;
        label.Text = labelText + ": " + compose(fmt, value);
    end

    function update(liveValue, src, refreshMap)
        if nargin < 3
            refreshMap = true;
        end
        if ~isempty(src)
            src.UserData.Label.Text = src.UserData.LabelText + ": " + compose(src.UserData.Format, liveValue);
        end

        cfg.engine.rpm = sliderValue(widgets.rpm, src, liveValue);
        cfg.engine.load_pct = sliderValue(widgets.load, src, liveValue);
        cfg.engine.boost_target_kpa = sliderValue(widgets.boostTarget, src, liveValue);
        cfg.engine.boost_actual_kpa = sliderValue(widgets.boostActual, src, liveValue);
        cfg.engine.iat_c = sliderValue(widgets.iat, src, liveValue);
        cfg.fuel.lambda_base = sliderValue(widgets.lambdaBase, src, liveValue);
        cfg.fuel.lambda_measured = sliderValue(widgets.lambdaMeasured, src, liveValue);
        cfg.fuel.pressure_bar = sliderValue(widgets.fuelPressure, src, liveValue);
        cfg.injector.flow_cc_min = sliderValue(widgets.injectorFlow, src, liveValue);
        cfg.injector.deadtime_ms = sliderValue(widgets.deadtime, src, liveValue);
        cfg.injector.injection_window_deg = sliderValue(widgets.windowDeg, src, liveValue);
        cfg.electrical.v_boost = sliderValue(widgets.vBoost, src, liveValue);
        cfg.electrical.i_peak_a = sliderValue(widgets.iPeak, src, liveValue);
        cfg.electrical.i_hold_low_a = sliderValue(widgets.iHoldLow, src, liveValue);
        cfg.electrical.i_hold_high_a = max(sliderValue(widgets.iHoldHigh, src, liveValue), cfg.electrical.i_hold_low_a + 0.1);

        r = simulate_engine_fuel_control(cfg);
        drawStats(r);
        drawFuel(axFuel, r);
        drawTrace(axTrace, r);
        drawLambda(axLambda, r);
        if refreshMap
            drawMap(axMap, r);
        else
            updateMapMarker(axMap);
        end
        drawnow limitrate;
    end

    function value = sliderValue(slider, activeSlider, liveValue)
        if ~isempty(activeSlider) && slider == activeSlider
            value = liveValue;
        else
            value = slider.Value;
        end
    end

    function drawStats(r)
        values = [
            compose("%.2f ms", r.commanded_pw_ms)
            compose("%.3f", r.target_lambda)
            compose("%.1f mg", r.fuel_mass_per_cyl_mg)
            compose("%.0f mg", r.air_mass_per_cyl_mg)
            compose("%.0f %%", r.window_usage_pct)
            compose("%+.0f kPa", r.boost_error_kpa)
        ];
        for k = 1:6
            stats(k).Text = statNames(k) + newline + values(k);
        end
    end

    function drawFuel(ax, r)
        cla(ax);
        vals = [r.base_pw_ms, r.deadtime_ms, max(0, r.available_window_ms - r.commanded_pw_ms)];
        bar(ax, categorical(["fuel PW", "deadtime", "window headroom"]), vals);
        ylabel(ax, "ms");
        title(ax, "Pulse Width vs Injection Window");
        grid(ax, "on");
    end

    function drawTrace(ax, r)
        cla(ax);
        yyaxis(ax, "left");
        plot(ax, r.injector_trace.t_s * 1e3, r.injector_trace.current_a, "LineWidth", 1.5);
        ylabel(ax, "current A");
        yyaxis(ax, "right");
        plot(ax, r.injector_trace.t_s * 1e3, r.injector_trace.voltage_v, "LineWidth", 1.1);
        ylabel(ax, "Vdiff V");
        xlabel(ax, "ms");
        title(ax, "PT2000-Style Injector Event");
        grid(ax, "on");
    end

    function drawLambda(ax, r)
        cla(ax);
        x = categorical(["target lambda", "measured lambda", "target boost", "actual boost"]);
        y = [r.target_lambda, cfg.fuel.lambda_measured, r.target_manifold_kpa / 100, r.manifold_kpa / 100];
        bar(ax, x, y);
        title(ax, "Lambda and Manifold Pressure");
        ylabel(ax, "lambda or kPa/100");
        grid(ax, "on");
    end

    function drawMap(ax, ~)
        cla(ax);
        rpmGrid = linspace(800, 7600, 40);
        loadGrid = linspace(10, 120, 34);
        [rpmMesh, loadMesh] = meshgrid(rpmGrid, loadGrid);
        pw = zeros(size(rpmMesh));
        tmp = cfg;
        for row = 1:size(rpmMesh, 1)
            for col = 1:size(rpmMesh, 2)
                tmp.engine.rpm = rpmMesh(row, col);
                tmp.engine.load_pct = loadMesh(row, col);
                tmp.engine.boost_actual_kpa = cfg.engine.boost_actual_kpa * loadMesh(row, col) / max(cfg.engine.load_pct, 1);
                rr = simulate_engine_fuel_control(tmp);
                pw(row, col) = rr.commanded_pw_ms;
            end
        end
        contourf(ax, rpmGrid, loadGrid, pw, 12, "LineStyle", "none");
        hold(ax, "on");
        plot(ax, cfg.engine.rpm, cfg.engine.load_pct, "ko", "MarkerFaceColor", "w", "MarkerSize", 8);
        hold(ax, "off");
        colorbar(ax);
        xlabel(ax, "RPM");
        ylabel(ax, "load %");
        title(ax, "Pulse Width Map, Current Point Marked");
    end

    function updateMapMarker(ax)
        marker = findobj(ax, "Tag", "CurrentOperatingPoint");
        if isempty(marker) || ~isvalid(marker)
            return;
        end
        marker.XData = cfg.engine.rpm;
        marker.YData = cfg.engine.load_pct;
    end
end

function cfg = localDefaultConfig()
cfg = simulate_engine_fuel_control().inputs;
end
