function fig = open_s58_gdi_live_dashboard()
%OPEN_S58_GDI_LIVE_DASHBOARD Tune and observe the running Simulink model.
folder = fileparts(mfilename("fullpath"));
addpath(folder);
model = "s58_gdi_vehicle_controller";
if ~isfile(fullfile(folder, model + ".slx"))
    build_s58_gdi_simulink_model();
elseif ~bdIsLoaded(model)
    load_system(fullfile(folder, model + ".slx"));
end
projectData = initialize_s58_gdi_project();
cal = projectData.cal;
values = struct("rpm",1200,"loadPct",20,"boostTargetKPa",0, ...
    "boostActualKPa",0,"iatC",30,"batteryV",13.5, ...
    "measuredLambda",1,"railActualBar",100);

fig = uifigure("Name","S58 GDI Model-Based Development Dashboard", ...
    "Position",[60 45 1480 880],"CloseRequestFcn",@closeDashboard);
root = uigridlayout(fig,[2 1]); root.RowHeight={52,"1x"}; root.Padding=[10 10 10 10];
toolbar = uigridlayout(root,[1 8]); toolbar.ColumnWidth={150,90,90,90,"1x",150,150,170};
uilabel(toolbar,"Text","S58 GDI LIVE MODEL","FontWeight","bold","FontSize",18);
uibutton(toolbar,"Text","Run","ButtonPushedFcn",@runModel);
uibutton(toolbar,"Text","Pause","ButtonPushedFcn",@pauseModel);
uibutton(toolbar,"Text","Stop","ButtonPushedFcn",@stopModel);
status = uilabel(toolbar,"Text","Model stopped","HorizontalAlignment","right");
metricFuel = uilabel(toolbar,"Text","Fuel: -- mg","HorizontalAlignment","center");
metricPulse = uilabel(toolbar,"Text","Pulse: -- ms","HorizontalAlignment","center");
metricState = uilabel(toolbar,"Text","State: OFF","HorizontalAlignment","center","FontWeight","bold");

tabs = uitabgroup(root);
dashTab=uitab(tabs,"Title","Live operation"); mapTab=uitab(tabs,"Title","Calibration maps");
eventTab=uitab(tabs,"Title","Injector event"); archTab=uitab(tabs,"Title","System architecture");

dash = uigridlayout(dashTab,[1 2]); dash.ColumnWidth={390,"1x"};
controls=uigridlayout(dash,[9 3]); controls.ColumnWidth={120,"1x",82}; controls.RowHeight=repmat({72},1,9);
defs = {
 "RPM","rpm",600,8000,"rpm";
 "Engine load","loadPct",0,120,"%";
 "Boost target","boostTargetKPa",0,250,"kPa gauge";
 "Actual boost","boostActualKPa",0,250,"kPa gauge";
 "Intake air","iatC",-20,100,"C";
 "Battery","batteryV",8,16.5,"V";
 "Measured lambda","measuredLambda",0.7,1.2,"lambda";
 "Rail pressure","railActualBar",50,350,"bar"};
widgets=struct();
for k=1:size(defs,1)
    key=defs{k,2};
    uilabel(controls,"Text",defs{k,1},"FontWeight","bold");
    slider=uislider(controls,"Limits",[defs{k,3} defs{k,4}],"Value",values.(key),"MajorTicks",[]);
    field=uieditfield(controls,"numeric","Limits",[defs{k,3} defs{k,4}],"Value",values.(key));
    slider.ValueChangingFcn=@(~,e) liveInput(key,e.Value,true);
    slider.ValueChangedFcn=@(~,e) liveInput(key,e.Value,true);
    field.ValueChangedFcn=@(~,e) fieldInput(key,e.Value,slider);
    widgets.(key)=struct("slider",slider,"field",field,"unit",defs{k,5});
end
matchButton = uibutton(controls,"Text","Match boost target","ButtonPushedFcn",@matchBoost);
matchButton.Layout.Row=9;

plots=uigridlayout(dash,[2 2]);
axFuel=uiaxes(plots); title(axFuel,"Fuel request and injection window"); grid(axFuel,"on");
axCurrent=uiaxes(plots); title(axCurrent,"Peak / hold current"); grid(axCurrent,"on");
axLift=uiaxes(plots); title(axLift,"Needle lift and fuel flow"); grid(axLift,"on");
axTrack=uiaxes(plots); title(axTrack,"Boost and rail targets"); grid(axTrack,"on");

maps=uigridlayout(mapTab,[1 3]);
axFuelMap=uiaxes(maps); axLambdaMap=uiaxes(maps); axRailMap=uiaxes(maps);
drawMap(axFuelMap,cal.engine.rpmBp,cal.engine.loadBp,projectData.maps.fuelMg,"Fuel mass","mg/event");
drawMap(axLambdaMap,cal.engine.rpmBp,cal.engine.loadBp,cal.fuel.lambda,"Lambda target","lambda");
drawMap(axRailMap,cal.engine.rpmBp,cal.engine.loadBp,cal.fuel.railBar,"Rail target","bar");

eventGrid=uigridlayout(eventTab,[2 2]);
axEventCurrent=uiaxes(eventGrid); axEventVoltage=uiaxes(eventGrid); axEventLift=uiaxes(eventGrid); axEventFlow=uiaxes(eventGrid);

arch=uigridlayout(archTab,[3 6]); arch.RowHeight={120,120,120}; arch.ColumnWidth=repmat({"1x"},1,6);
nodes=["Vehicle plant","CAN Rx + validation","Fuel maps","Injection scheduler","Stateflow sequence","PT2000 plant", ...
    "Two-wire injector","Fuel delivery","Diagnostics","CAN Tx status","SIL tests","Embedded Coder"];
for k=1:numel(nodes)
    p=uipanel(arch,"Title",nodes(k),"FontWeight","bold");
    uilabel(p,"Text",nodeText(k),"Position",[10 10 190 55],"WordWrap","on");
end
updateAll();

    function liveInput(key,value,fullRefresh)
        values.(key)=value; widgets.(key).field.Value=value; tuneModel();
        if fullRefresh, updateAll(); else, drawnow limitrate; end
    end
    function fieldInput(key,value,slider)
        values.(key)=value; slider.Value=value; tuneModel(); updateAll();
    end
    function matchBoost(~,~)
        values.boostActualKPa=values.boostTargetKPa;
        widgets.boostActualKPa.slider.Value=values.boostActualKPa;
        widgets.boostActualKPa.field.Value=values.boostActualKPa; tuneModel(); updateAll();
    end
    function tuneModel()
        vector=[values.rpm values.loadPct values.boostTargetKPa values.boostActualKPa ...
            values.iatC values.batteryV values.measuredLambda values.railActualBar];
        assignin("base","S58_LIVE_INPUT",vector);
        set_param(model+"/Live Vehicle Inputs","Value",mat2str(vector,8));
    end
    function runModel(~,~)
        tuneModel(); set_param(model,"SimulationCommand","start"); status.Text="RUNNING - live inputs";
    end
    function pauseModel(~,~)
        state=get_param(model,"SimulationStatus");
        if state=="paused", set_param(model,"SimulationCommand","continue"); status.Text="RUNNING - live inputs";
        elseif state=="running", set_param(model,"SimulationCommand","pause"); status.Text="PAUSED"; end
    end
    function stopModel(~,~), set_param(model,"SimulationCommand","stop"); status.Text="Model stopped"; end
    function updateAll()
        point=s58_gdi_operating_point(values,cal); point.batteryV=values.batteryV; point.coilTempC=80;
        event=s58_gdi_injector_event(point,cal);
        metricFuel.Text=sprintf("Fuel: %.2f mg",point.fuelRequestMg);
        metricPulse.Text=sprintf("Pulse: %.3f ms",point.pulseWidthMs);
        if point.flags.windowExceeded, metricState.Text="State: WINDOW LIMIT"; else, metricState.Text="State: SCHEDULED"; end
        bar(axFuel,[point.fuelRequestMg event.deliveredMg]); axFuel.XTickLabel={"requested","delivered proxy"}; ylabel(axFuel,"mg");
        plot(axCurrent,event.tS*1e3,event.currentA,"LineWidth",1.4); xlabel(axCurrent,"ms"); ylabel(axCurrent,"A");
        yyaxis(axLift,"left"); plot(axLift,event.tS*1e3,event.normalizedLift,"LineWidth",1.3); ylabel(axLift,"normalized lift");
        yyaxis(axLift,"right"); plot(axLift,event.tS*1e3,event.flowMgPerS,"LineWidth",1.1); ylabel(axLift,"mg/s"); xlabel(axLift,"ms");
        bar(axTrack,[values.boostTargetKPa values.boostActualKPa; point.railTargetBar values.railActualBar]);
        axTrack.XTickLabel={"boost kPa","rail bar"}; legend(axTrack,{"target","actual"},"Location","best");
        plot(axEventCurrent,event.tS*1e3,event.currentA); title(axEventCurrent,"Coil current (A)"); grid(axEventCurrent,"on");
        plot(axEventVoltage,event.tS*1e3,event.voltageV); title(axEventVoltage,"Injector differential voltage (V)"); grid(axEventVoltage,"on");
        plot(axEventLift,event.tS*1e3,event.normalizedLift); title(axEventLift,"Normalized armature lift"); grid(axEventLift,"on");
        plot(axEventFlow,event.tS*1e3,event.flowMgPerS); title(axEventFlow,"Instantaneous fuel flow (mg/s)"); grid(axEventFlow,"on");
    end
    function closeDashboard(~,~)
        if bdIsLoaded(model) && get_param(model,"SimulationStatus")~="stopped", set_param(model,"SimulationCommand","stop"); end
        delete(fig);
    end
end

function drawMap(ax,x,y,z,name,unit)
imagesc(ax,x,y,z); axis(ax,"xy"); colorbar(ax); xlabel(ax,"RPM"); ylabel(ax,"load %"); title(ax,name+" ("+unit+")");
end

function text = nodeText(index)
items=["RPM, load, boost, lambda, rail pressure", "Range, timeout, counter and CRC boundary", ...
"VE, lambda and rail-pressure lookup tables", "Fuel mass, pulse width, cycle-window checks", ...
"OFF, BOOST, HOLD, FLYBACK and FAULT", "Boost rail, switches, current sensing and clamp", ...
"Coil current, armature motion and EOI", "Integrated mass and cylinder request comparison", ...
"Open/short, overcurrent, stale CAN and tracking", "Delivered mass, state and fault telemetry", ...
"Nominal, boundary and fault scenarios", "ERT C/C++ plus SIL/PIL equivalence"];
text=items(index);
end
