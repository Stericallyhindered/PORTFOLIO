# S58 GDI Model-Based Development Demonstrator

This project is an executable Simulink/Stateflow architecture demonstrator for
a six-cylinder GDI controller and PT2000-style injector driver. It is structured
like a production model-based development project, but it is not approved engine
control software or a released hardware calibration.

## Run the live model

In MATLAB, change to this folder and run:

```matlab
build_s58_gdi_simulink_model
add_native_simulink_dashboard
open_s58_gdi_live_dashboard
```

Press **Run** in the dashboard. The model runs continuously until **Stop** is
pressed. RPM, engine load, boost target, actual boost, intake temperature,
battery voltage, measured lambda, and rail pressure are tunable while running.

`add_native_simulink_dashboard` creates the preferred dashboard directly inside
the Simulink model. Open the `Operator Dashboard` subsystem and use the normal
Simulink Run/Pause/Stop controls. `open_s58_gdi_live_dashboard` remains a
standalone MATLAB presentation view.

## Executable architecture

- `s58_gdi_vehicle_controller.slx`: generated Simulink/Stateflow model.
- CAN receive boundary: range validation and explicit signal interface.
- Fuel scheduler: RPM/load lookup tables for fuel mass and lambda target.
- Injection controller: cycle-phase scheduling and Stateflow OFF/BOOST/HOLD/
  FLYBACK sequencing using coil-current feedback.
- Driver plant: boost/battery selection and discrete RL injector-coil dynamics.
- Monitoring: logged fuel request, lambda target, current, and delivery proxy.
- CAN transmit boundary: typed driver-status bus.

The eight-second scenario in `run_s58_gdi_scenario.m` is a deterministic test
fixture only. It is not the live operator experience.

## Verification

Run:

```matlab
results = runtests("test_s58_gdi_model.m");
assertSuccess(results)
```

The current tests verify increasing fuel demand with load, deterministic CAN
counter/CRC encoding, and physically bounded injector current/delivery behavior.

## Evidence and limitations

`s58_gdi_calibration.m` is the single source for units, maps, limits, model
revision, and provenance status. Injector resistance, inductance, flow,
opening-current threshold, mechanical time constants, and PT2000 current profile
are explicitly marked `ESTIMATE`. Replace them with controlled measurements and
verified component documentation before hardware design decisions.

Production release still requires:

1. Measured injector V-I, opening/closing, mass-flow, pressure, temperature, and
   short-pulse characterization with uncertainty bounds.
2. PT2000 register/microcode design against the exact silicon revision and NXP
   safety documentation.
3. A selected MCU, target compiler, scheduler, SPI/CAN hardware abstraction,
   watchdog strategy, and measured execution-time budget.
4. Detailed power-stage schematic, device derating, boost-converter design,
   grounding, connector, fuse, transient, thermal, EMC, and fault analysis.
5. Requirements traceability, model standards checks, coverage, back-to-back
   MIL/SIL/PIL results, HIL fault injection, and independent review.
6. Bench validation with current-limited supplies and non-fueled loads before
   any injector, rail, or engine testing.

## Project files

- `build_s58_gdi_simulink_model.m`: deterministic model generator.
- `initialize_s58_gdi_project.m`: model workspace and derived map setup.
- `open_s58_gdi_live_dashboard.m`: live operator and presentation dashboard.
- `s58_gdi_operating_point.m`: independent reference calculation.
- `s58_gdi_injector_event.m`: high-resolution reference injector event.
- `s58_gdi_can_codec.m`: deterministic CAN-FD demonstrator framing.
- `test_s58_gdi_model.m`: automated regression tests.
