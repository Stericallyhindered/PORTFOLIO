function result = simulate_single_injector(p)
%SIMULATE_SINGLE_INJECTOR Simulate a single two-wire peak/hold injector channel.
%
% The model is an electrical first pass: V = L di/dt + iR. It captures
% boost-assisted opening, battery hold chopping, and flyback clamp behavior.

arguments
    p struct = init_s58_injector_params()
end

dt = p.control.dt_s;
t = 0:dt:p.control.t_total_s;
n = numel(t);

i = zeros(1, n);
v = zeros(1, n);
state = strings(1, n);

r_total = p.injector.R_ohm + p.driver.switch_r_ohm;
peak_reached = false;

for k = 2:n
    tk = t(k);
    ik = i(k - 1);

    if tk <= p.control.t_injection_s
        if ~peak_reached
            vk = p.driver.v_boost;
            sk = "boost peak";
            if ik >= p.control.i_peak_a || tk >= p.control.t_peak_max_s
                peak_reached = true;
            end
        else
            if ik <= p.control.i_hold_low_a
                vk = p.driver.v_hold;
                sk = "hold on";
            elseif ik >= p.control.i_hold_high_a
                vk = 0;
                sk = "hold recirc";
            else
                vk = v(k - 1);
                sk = state(k - 1);
            end
        end
    else
        if ik > 0.01
            vk = p.driver.v_clamp;
            sk = "flyback clamp";
        else
            vk = 0;
            sk = "off";
        end
    end

    didt = (vk - ik * r_total) / p.injector.L_h;
    i(k) = max(0, ik + didt * dt);
    v(k) = vk;
    state(k) = sk;
end

p_coil = i.^2 * p.injector.R_ohm;
p_switch = i.^2 * p.driver.switch_r_ohm;
e_coil_j = trapz(t, p_coil);
e_switch_j = trapz(t, p_switch);
e_magnetic_peak_j = 0.5 * p.injector.L_h * max(i)^2;

result.t_s = t;
result.current_a = i;
result.voltage_v = v;
result.state = state;
result.metrics.peak_current_a = max(i);
result.metrics.current_at_eoi_a = interp1(t, i, p.control.t_injection_s, "linear");
result.metrics.coil_energy_j = e_coil_j;
result.metrics.switch_energy_j = e_switch_j;
result.metrics.peak_magnetic_energy_j = e_magnetic_peak_j;
result.params = p;
end
