p = init_s58_injector_params();
r = simulate_single_injector(p);
plot_single_injector_result(r);
