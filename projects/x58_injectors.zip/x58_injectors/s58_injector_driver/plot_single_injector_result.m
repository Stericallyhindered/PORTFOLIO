function plot_single_injector_result(result)
%PLOT_SINGLE_INJECTOR_RESULT Plot current, voltage, and coarse driver state.

t_ms = result.t_s * 1e3;

figure("Name", "S58/PT2000 single injector channel", "Color", "w");
tiledlayout(3, 1, "TileSpacing", "compact");

nexttile;
plot(t_ms, result.current_a, "LineWidth", 1.5);
grid on;
ylabel("Current (A)");
title("Peak-and-hold injector current");

nexttile;
plot(t_ms, result.voltage_v, "LineWidth", 1.5);
grid on;
ylabel("Injector Vdiff (V)");
title("Two-lead differential drive voltage");

nexttile;
states = categorical(result.state);
stairs(t_ms, double(states), "LineWidth", 1.2);
grid on;
yticks(1:numel(categories(states)));
yticklabels(categories(states));
xlabel("Time (ms)");
title("Driver phase");

fprintf("Peak current: %.2f A\n", result.metrics.peak_current_a);
fprintf("Current at end of injection: %.2f A\n", result.metrics.current_at_eoi_a);
fprintf("Coil I^2R energy: %.4f J\n", result.metrics.coil_energy_j);
fprintf("Switch I^2R energy: %.4f J\n", result.metrics.switch_energy_j);
fprintf("Peak magnetic energy: %.4f J\n", result.metrics.peak_magnetic_energy_j);
end
