function data = initialize_s58_gdi_project()
%INITIALIZE_S58_GDI_PROJECT Create model inputs and derived calibration maps.
cal = s58_gdi_calibration();
[rpm, loadPct] = meshgrid(cal.engine.rpmBp, cal.engine.loadBp);
ambient = cal.engine.ambientKPa;
boost = max(0, (loadPct - 55) / 65 * 190);
manifoldPa = (ambient + boost) * 1000;
rho = manifoldPa ./ (cal.engine.gasConstant * (35 + 273.15));
cylinderM3 = cal.engine.displacementL / 1000 / cal.engine.cylinders;
airMg = rho * cylinderM3 .* cal.fuel.ve * 1e6;
fuelMg = airMg ./ (cal.engine.stoichAfr * cal.fuel.lambda);
flowMgMs = cal.injector.flowMgPerMsAt200Bar .* ...
    sqrt(cal.fuel.railBar / cal.injector.ratedPressureBar);
pulseMs = fuelMg ./ flowMgMs + interp1(cal.injector.deadtimeBattV, ...
    cal.injector.deadtimeMs, 13.5);

scenario = run_s58_gdi_scenario(8, 0.001, cal);
scenarioMatrix = [scenario.timeS scenario.rpm scenario.loadPct ...
    scenario.boostTargetKPa scenario.boostActualKPa ...
    35 + 12 * scenario.timeS / scenario.timeS(end) ...
    13.5 * ones(size(scenario.timeS)) scenario.lambdaTarget ...
    scenario.railTargetBar];

data.cal = cal;
data.maps.fuelMg = fuelMg;
data.maps.pulseMs = pulseMs;
data.scenario = scenario;
data.scenarioMatrix = scenarioMatrix;
assignin("base", "S58_CAL", cal);
assignin("base", "S58_FUEL_MG_MAP", fuelMg);
assignin("base", "S58_PULSE_MS_MAP", pulseMs);
assignin("base", "S58_SCENARIO", scenarioMatrix);
assignin("base", "S58_LIVE_INPUT", [1200 20 0 0 30 13.5 1.0 100]);
end
