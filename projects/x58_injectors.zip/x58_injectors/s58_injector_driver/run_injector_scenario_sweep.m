base = init_s58_injector_params();

scenarios = struct([]);

scenarios(1).name = "nominal";
scenarios(1).params = base;

scenarios(2).name = "low battery";
scenarios(2).params = base;
scenarios(2).params.driver.v_batt = 10.5;
scenarios(2).params.driver.v_hold = 10.5;

scenarios(3).name = "hot coil";
scenarios(3).params = base;
scenarios(3).params.injector.R_ohm = base.injector.R_ohm * 1.35;

scenarios(4).name = "high inductance";
scenarios(4).params = base;
scenarios(4).params.injector.L_h = base.injector.L_h * 1.35;

scenarios(5).name = "boost sag";
scenarios(5).params = base;
scenarios(5).params.driver.v_boost = 52.0;

results = cell(1, numel(scenarios));
for idx = 1:numel(scenarios)
    results{idx} = simulate_single_injector(scenarios(idx).params);
end

figure("Name", "S58/PT2000 injector scenario sweep", "Color", "w");
tiledlayout(3, 1, "TileSpacing", "compact");

nexttile;
hold on;
for idx = 1:numel(results)
    plot(results{idx}.t_s * 1e3, results{idx}.current_a, "LineWidth", 1.3);
end
hold off;
grid on;
ylabel("Current (A)");
title("Injector current scenarios");
legend({scenarios.name}, "Location", "eastoutside");

nexttile;
hold on;
for idx = 1:numel(results)
    plot(results{idx}.t_s * 1e3, results{idx}.voltage_v, "LineWidth", 1.0);
end
hold off;
grid on;
ylabel("Vdiff (V)");
title("Differential injector voltage");

nexttile;
peakCurrent = zeros(1, numel(results));
eSwitch = zeros(1, numel(results));
eCoil = zeros(1, numel(results));
for idx = 1:numel(results)
    peakCurrent(idx) = results{idx}.metrics.peak_current_a;
    eSwitch(idx) = results{idx}.metrics.switch_energy_j;
    eCoil(idx) = results{idx}.metrics.coil_energy_j;
end
scenarioNames = cellstr([scenarios.name]);
bar(categorical(scenarioNames), [peakCurrent(:), 100 * eSwitch(:), 100 * eCoil(:)]);
grid on;
ylabel("A or J x100");
title("Peak current and energy comparison");
legend(["peak current A", "switch energy J x100", "coil energy J x100"], "Location", "eastoutside");

fprintf("\nScenario sweep\n");
fprintf("%-16s %10s %12s %12s %12s\n", "case", "peak A", "EOI A", "coil J", "switch J");
for idx = 1:numel(results)
    m = results{idx}.metrics;
    fprintf("%-16s %10.2f %12.2f %12.4f %12.4f\n", ...
        scenarios(idx).name, ...
        m.peak_current_a, ...
        m.current_at_eoi_a, ...
        m.coil_energy_j, ...
        m.switch_energy_j);
end
