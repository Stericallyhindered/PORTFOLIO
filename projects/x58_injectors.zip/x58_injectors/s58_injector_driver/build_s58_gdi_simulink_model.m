function modelPath = build_s58_gdi_simulink_model()
%BUILD_S58_GDI_SIMULINK_MODEL Build the graphical executable architecture.
folder = fileparts(mfilename("fullpath"));
addpath(folder);
initialize_s58_gdi_project();
model = "s58_gdi_vehicle_controller";
modelPath = fullfile(folder, model + ".slx");
if bdIsLoaded(model), close_system(model, 0); end
if isfile(modelPath), delete(modelPath); end
new_system(model);
set_param(model, "SolverType", "Fixed-step", "Solver", "FixedStepDiscrete", ...
    "FixedStep", "1e-4", "StopTime", "inf", "SignalLogging", "on", ...
    "SaveOutput", "on", "ReturnWorkspaceOutputs", "on", ...
    "BlockReduction", "off", "OptimizeBlockIOStorage", "off", ...
    "DefaultParameterBehavior", "Tunable");
set_param(model, "PreLoadFcn", "initialize_s58_gdi_project();");

add_block("simulink/Sources/Constant", model + "/Live Vehicle Inputs", ...
    "Value", "[1200 20 0 0 30 13.5 1.0 100]", "Position", [30 145 145 185]);
add_block("simulink/Signal Routing/Demux", model + "/Vehicle Signal Decode", ...
    "Outputs", "8", "Position", [180 70 185 320]);
add_line(model, "Live Vehicle Inputs/1", "Vehicle Signal Decode/1");
labels = ["RPM","Load_pct","Boost_Target_kPa","Boost_Actual_kPa", ...
    "IAT_C","Battery_V","Lambda_Measured","Rail_Actual_bar"];
for k = 1:numel(labels)
    add_block("simulink/Signal Attributes/Signal Specification", ...
        model + "/" + labels(k), "Position", [220 35+35*k 305 55+35*k]);
    add_line(model, "Vehicle Signal Decode/" + k, labels(k) + "/1");
end

makeCanRx(model);
makeFuelScheduler(model);
makeInjectionController(model);
makeDriverPlant(model);
makeCanTx(model);
makeMonitoring(model);

add_line(model, "RPM/1", "CAN Receive and Validation/1");
add_line(model, "Load_pct/1", "CAN Receive and Validation/2");
add_line(model, "Boost_Actual_kPa/1", "CAN Receive and Validation/3");
add_line(model, "Battery_V/1", "CAN Receive and Validation/4");
add_line(model, "CAN Receive and Validation/1", "Fuel Mass and Lambda Scheduling/1");
add_line(model, "CAN Receive and Validation/2", "Fuel Mass and Lambda Scheduling/2");
add_line(model, "Fuel Mass and Lambda Scheduling/1", "Injection Event Controller/1");
add_line(model, "Fuel Mass and Lambda Scheduling/2", "Injection Event Controller/2");
add_line(model, "CAN Receive and Validation/4", "Injection Event Controller/3");
add_line(model, "CAN Receive and Validation/1", "Injection Event Controller/5");
add_line(model, "Injection Event Controller/1", "PT2000 and Injector Plant/1");
add_line(model, "Injection Event Controller/2", "PT2000 and Injector Plant/2");
add_line(model, "CAN Receive and Validation/4", "PT2000 and Injector Plant/3");
add_line(model, "PT2000 and Injector Plant/1", "Injection Event Controller/4");
add_line(model, "Fuel Mass and Lambda Scheduling/1", "CAN Transmit Status/1");
add_line(model, "Injection Event Controller/1", "CAN Transmit Status/2");
add_line(model, "PT2000 and Injector Plant/1", "CAN Transmit Status/3");
add_line(model, "Fuel Mass and Lambda Scheduling/1", "Model Monitoring/1");
add_line(model, "Fuel Mass and Lambda Scheduling/2", "Model Monitoring/2");
add_line(model, "PT2000 and Injector Plant/1", "Model Monitoring/3");
add_line(model, "PT2000 and Injector Plant/2", "Model Monitoring/4");

set_param(model + "/CAN Receive and Validation", "BackgroundColor", "lightBlue");
set_param(model + "/Fuel Mass and Lambda Scheduling", "BackgroundColor", "green");
set_param(model + "/Injection Event Controller", "BackgroundColor", "yellow");
set_param(model + "/PT2000 and Injector Plant", "BackgroundColor", "orange");
set_param(model + "/CAN Transmit Status", "BackgroundColor", "lightBlue");
set_param(model + "/Model Monitoring", "BackgroundColor", "gray");
Simulink.BlockDiagram.arrangeSystem(model);
set_param(model, "ZoomFactor", "FitSystem");

if license("test", "RTW_Embedded_Coder")
    set_param(model, "SystemTargetFile", "ert.tlc", ...
        "GenerateReport", "on", "LaunchReport", "off");
end
save_system(model, modelPath);
open_system(model);
end

function makeCanRx(model)
name = model + "/CAN Receive and Validation";
add_block("simulink/Ports & Subsystems/Subsystem", name, "Position", [350 55 535 205]);
Simulink.SubSystem.deleteContents(name);
for k = 1:4
    add_block("simulink/Ports & Subsystems/In1", name + "/In" + k, ...
        "Port", string(k), "Position", [25 25+35*k 55 39+35*k]);
    add_block("simulink/Ports & Subsystems/Out1", name + "/Validated" + k, ...
        "Port", string(k), "Position", [250 25+35*k 280 39+35*k]);
    add_block("simulink/Discontinuities/Saturation", name + "/Range Check " + k, ...
        "UpperLimit", upperLimit(k), "LowerLimit", lowerLimit(k), ...
        "Position", [100 22+35*k 190 42+35*k]);
    add_line(name, "In"+k+"/1", "Range Check "+k+"/1");
    add_line(name, "Range Check "+k+"/1", "Validated"+k+"/1");
end
end

function makeFuelScheduler(model)
name = model + "/Fuel Mass and Lambda Scheduling";
add_block("simulink/Ports & Subsystems/Subsystem", name, "Position", [590 65 790 185]);
Simulink.SubSystem.deleteContents(name);
add_block("simulink/Ports & Subsystems/In1", name+"/RPM", "Position", [25 48 55 62]);
add_block("simulink/Ports & Subsystems/In1", name+"/Load", "Port", "2", "Position", [25 98 55 112]);
add_block("simulink/Lookup Tables/2-D Lookup Table", name+"/Fuel Mass Map", ...
    "BreakpointsForDimension1", "S58_CAL.engine.rpmBp", ...
    "BreakpointsForDimension2", "S58_CAL.engine.loadBp", ...
    "Table", "S58_FUEL_MG_MAP'", "InterpMethod", "Linear point-slope", ...
    "Position", [100 35 220 80]);
add_block("simulink/Lookup Tables/2-D Lookup Table", name+"/Lambda Target Map", ...
    "BreakpointsForDimension1", "S58_CAL.engine.rpmBp", ...
    "BreakpointsForDimension2", "S58_CAL.engine.loadBp", ...
    "Table", "S58_CAL.fuel.lambda'", "InterpMethod", "Linear point-slope", ...
    "Position", [100 90 220 135]);
for block = ["Fuel Mass Map","Lambda Target Map"]
    add_line(name, "RPM/1", block+"/1"); add_line(name, "Load/1", block+"/2");
end
add_block("simulink/Ports & Subsystems/Out1", name+"/Fuel_mg", "Position", [270 50 300 64]);
add_block("simulink/Ports & Subsystems/Out1", name+"/Lambda_Target", "Port", "2", "Position", [270 105 300 119]);
add_line(name, "Fuel Mass Map/1", "Fuel_mg/1");
add_line(name, "Lambda Target Map/1", "Lambda_Target/1");
end

function makeInjectionController(model)
name = model + "/Injection Event Controller";
add_block("simulink/Ports & Subsystems/Subsystem", name, "Position", [850 55 1045 220]);
Simulink.SubSystem.deleteContents(name);
inputs = ["Fuel_mg","Lambda_Target","Battery_V","Coil_Current_A","RPM"];
for k=1:5, add_block("simulink/Ports & Subsystems/In1",name+"/"+inputs(k),"Port",string(k),"Position",[20 15+32*k 50 29+32*k]); end
% Fuel request is converted to pulse width with the calibrated nominal slope.
add_block("simulink/Math Operations/Gain", name+"/Fuel mass to pulse", ...
    "Gain","1/S58_CAL.injector.flowMgPerMsAt200Bar", "Position",[95 105 205 135]);
add_block("simulink/Math Operations/Bias", name+"/Deadtime compensation", ...
    "Bias","0.32", "Position",[235 105 335 135]);
add_block("simulink/Logic and Bit Operations/Compare To Constant", name+"/Peak reached", ...
    "const","S58_CAL.driver.peakCurrentA", "relop",">=", "Position",[95 155 205 185]);
add_block("simulink/Signal Routing/Switch", name+"/Peak Hold Selector", ...
    "Threshold","0.5", "Position",[375 95 425 155]);
add_block("simulink/Signal Routing/Switch", name+"/Injection Enable", ...
    "Threshold","0.5", "Position",[455 100 505 160]);
add_block("simulink/Sources/Constant", name+"/Peak Mode", "Value","1", "Position",[270 155 310 175]);
add_block("simulink/Sources/Constant", name+"/Hold Mode", "Value","2", "Position",[270 190 310 210]);
add_block("simulink/Sources/Constant", name+"/Off Mode", "Value","0", "Position",[375 205 415 225]);
add_block("simulink/Math Operations/Gain", name+"/Cycle frequency", "Gain","1/120", "Position",[95 220 175 245]);
add_block("simulink/Discrete/Discrete-Time Integrator", name+"/Engine cycle phase", ...
    "gainval","1e-4", "InitialCondition","0", "Position",[205 220 285 245]);
add_block("simulink/Math Operations/Math Function", name+"/Modulo one", ...
    "Operator","mod", "Position",[315 220 365 245]);
add_block("simulink/Sources/Constant", name+"/One", "Value","1", "Position",[300 255 330 275]);
add_block("simulink/Math Operations/Product", name+"/Pulse fraction", "Inputs","**/", "Position",[235 45 270 80]);
add_block("simulink/Sources/Constant", name+"/Milliseconds per cycle scale", "Value","120000", "Position",[165 20 225 40]);
add_block("simulink/Logic and Bit Operations/Relational Operator", name+"/Inside injection window", ...
    "Operator","<", "Position",[380 240 425 270]);
addSequenceChart(name);
add_block("simulink/Ports & Subsystems/Out1", name+"/Gate_Mode", "Position",[690 120 720 134]);
add_block("simulink/Ports & Subsystems/Out1", name+"/Pulse_ms", "Port","2", "Position",[550 65 580 79]);
add_line(name,"Fuel_mg/1","Fuel mass to pulse/1"); add_line(name,"Fuel mass to pulse/1","Deadtime compensation/1");
add_line(name,"Deadtime compensation/1","Pulse_ms/1"); add_line(name,"Coil_Current_A/1","Peak reached/1");
add_line(name,"Peak Mode/1","Peak Hold Selector/1"); add_line(name,"Peak reached/1","Peak Hold Selector/2");
add_line(name,"Hold Mode/1","Peak Hold Selector/3");
add_line(name,"RPM/1","Cycle frequency/1"); add_line(name,"Cycle frequency/1","Engine cycle phase/1");
add_line(name,"Engine cycle phase/1","Modulo one/1"); add_line(name,"One/1","Modulo one/2");
add_line(name,"Deadtime compensation/1","Pulse fraction/1"); add_line(name,"RPM/1","Pulse fraction/2");
add_line(name,"Milliseconds per cycle scale/1","Pulse fraction/3");
add_line(name,"Modulo one/1","Inside injection window/1"); add_line(name,"Pulse fraction/1","Inside injection window/2");
add_line(name,"Peak Hold Selector/1","Injection Enable/1"); add_line(name,"Inside injection window/1","Injection Enable/2");
add_line(name,"Off Mode/1","Injection Enable/3");
add_line(name,"Injection Enable/1","PT2000 Sequence Supervisor/1");
add_line(name,"Coil_Current_A/1","PT2000 Sequence Supervisor/2");
add_line(name,"PT2000 Sequence Supervisor/1","Gate_Mode/1");
end

function addSequenceChart(parent)
block = parent + "/PT2000 Sequence Supervisor";
add_block("sflib/Chart", block, "Position", [545 105 650 165]);
root = sfroot;
chart = root.find("-isa", "Stateflow.Chart", "Name", "PT2000 Sequence Supervisor");
chart = chart(end);
chart.ChartUpdate = "DISCRETE";
chart.SampleTime = "1e-4";

requested = Stateflow.Data(chart); requested.Name = "requestedMode"; requested.Scope = "Input";
coil = Stateflow.Data(chart); coil.Name = "coilCurrent"; coil.Scope = "Input";
gate = Stateflow.Data(chart); gate.Name = "gateMode"; gate.Scope = "Output";

off = makeState(chart, "OFF", [40 40 90 55], "entry: gateMode = 0;");
boost = makeState(chart, "BOOST", [190 40 100 55], "entry: gateMode = 1;");
hold = makeState(chart, "HOLD", [350 40 90 55], "entry: gateMode = 2;");
flyback = makeState(chart, "FLYBACK", [190 155 105 55], "entry: gateMode = 3;");
makeTransition(chart, [], off, "", 0, 0);
makeTransition(chart, off, boost, "[requestedMode > 0]", 3, 9);
makeTransition(chart, boost, hold, "[coilCurrent >= 11 || requestedMode == 2]", 3, 9);
makeTransition(chart, hold, flyback, "[requestedMode == 0]", 6, 0);
makeTransition(chart, flyback, off, "[coilCurrent <= 0.1]", 9, 3);
end

function state = makeState(chart, name, position, action)
state = Stateflow.State(chart);
state.Name = name;
state.Position = position;
state.LabelString = name + newline + action;
end

function transition = makeTransition(chart, source, destination, label, sourceClock, destinationClock)
transition = Stateflow.Transition(chart);
if ~isempty(source), transition.Source = source; transition.SourceOClock = sourceClock; end
transition.Destination = destination;
transition.DestinationOClock = destinationClock;
transition.LabelString = label;
end

function makeDriverPlant(model)
name=model+"/PT2000 and Injector Plant";
add_block("simulink/Ports & Subsystems/Subsystem",name,"Position",[1110 55 1295 205]);
Simulink.SubSystem.deleteContents(name);
for k=1:3, add_block("simulink/Ports & Subsystems/In1",name+"/In"+k,"Port",string(k),"Position",[20 25+40*k 50 39+40*k]); end
add_block("simulink/Signal Routing/Switch",name+"/Boost or Battery","Threshold","1.5","Position",[155 55 205 105]);
add_block("simulink/Sources/Constant",name+"/Boost Rail","Value","S58_CAL.driver.boostV","Position",[75 45 120 65]);
add_block("simulink/Discrete/Discrete Transfer Fcn",name+"/Coil RL Dynamics", ...
    "Numerator","[0 (1-exp(-(S58_CAL.injector.coilR25Ohm+S58_CAL.driver.switchROhm)*1e-4/S58_CAL.injector.coilLH))/(S58_CAL.injector.coilR25Ohm+S58_CAL.driver.switchROhm)]", ...
    "Denominator","[1 -exp(-(S58_CAL.injector.coilR25Ohm+S58_CAL.driver.switchROhm)*1e-4/S58_CAL.injector.coilLH)]", ...
    "Position",[250 65 365 105]);
add_block("simulink/Discontinuities/Saturation",name+"/Armature lift proxy","UpperLimit","1","LowerLimit","0", "Position",[250 125 365 155]);
add_block("simulink/Ports & Subsystems/Out1",name+"/Coil_Current_A","Position",[415 75 445 89]);
add_block("simulink/Ports & Subsystems/Out1",name+"/Delivered_Fuel_Proxy","Port","2","Position",[415 135 445 149]);
add_line(name,"Boost Rail/1","Boost or Battery/1"); add_line(name,"In1/1","Boost or Battery/2"); add_line(name,"In3/1","Boost or Battery/3");
add_line(name,"Boost or Battery/1","Coil RL Dynamics/1"); add_line(name,"Coil RL Dynamics/1","Coil_Current_A/1");
add_line(name,"Coil RL Dynamics/1","Armature lift proxy/1"); add_line(name,"Armature lift proxy/1","Delivered_Fuel_Proxy/1");
end

function makeCanTx(model)
name=model+"/CAN Transmit Status";
add_block("simulink/Ports & Subsystems/Subsystem",name,"Position",[1360 55 1515 180]);
Simulink.SubSystem.deleteContents(name);
for k=1:3, add_block("simulink/Ports & Subsystems/In1",name+"/Signal"+k,"Port",string(k),"Position",[20 25+35*k 50 39+35*k]); end
add_block("simulink/Signal Routing/Bus Creator",name+"/Driver Status Bus","Inputs","3","Position",[105 55 110 145]);
for k=1:3, add_line(name,"Signal"+k+"/1","Driver Status Bus/"+k); end
end

function makeMonitoring(model)
name=model+"/Model Monitoring";
add_block("simulink/Ports & Subsystems/Subsystem",name,"Position",[1110 260 1295 410]);
Simulink.SubSystem.deleteContents(name);
for k=1:4
 add_block("simulink/Ports & Subsystems/In1",name+"/Signal"+k,"Port",string(k),"Position",[20 20+30*k 50 34+30*k]);
 add_block("simulink/Sinks/To Workspace",name+"/Log"+k,"VariableName","S58_LOG_"+k,"SaveFormat","Timeseries","Position",[105 17+30*k 190 37+30*k]);
 add_line(name,"Signal"+k+"/1","Log"+k+"/1");
end
end

function v=upperLimit(k), values=[8000 130 250 18]; v=string(values(k)); end
function v=lowerLimit(k), values=[0 0 -20 6]; v=string(values(k)); end
