function p = init_s58_injector_params()
%INIT_S58_INJECTOR_PARAMS Baseline parameters for an S58-style GDI injector driver.
%
% Values here are placeholders for architecture work. Replace coil, current,
% and timing numbers with measured injector and PT2000 configuration data.

p.injector.R_ohm = 1.25;
p.injector.L_h = 280e-6;
p.injector.name = "S58 injector placeholder";

p.driver.v_batt = 13.5;
p.driver.v_boost = 65.0;
p.driver.v_hold = 13.5;
p.driver.v_clamp = -55.0;
p.driver.r_sense_ohm = 0.03;
p.driver.switch_r_ohm = 0.08;

p.control.i_peak_a = 11.0;
p.control.i_hold_high_a = 4.2;
p.control.i_hold_low_a = 3.4;
p.control.t_peak_max_s = 0.55e-3;
p.control.t_injection_s = 2.20e-3;
p.control.t_total_s = 3.20e-3;
p.control.dt_s = 0.25e-6;

p.arch.channels = 6;
p.arch.driver_ic = "NXP PT2000/PT2001 family target";
p.arch.measurement = "Differential injector voltage + current clamp";
end
