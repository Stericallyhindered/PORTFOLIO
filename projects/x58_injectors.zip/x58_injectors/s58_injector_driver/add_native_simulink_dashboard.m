function add_native_simulink_dashboard()
%ADD_NATIVE_SIMULINK_DASHBOARD Add a connected dashboard inside the SLX model.
folder = fileparts(mfilename("fullpath"));
model = "s58_gdi_vehicle_controller";
modelFile = fullfile(folder, model + ".slx");
initialize_s58_gdi_project();
if ~isfile(modelFile)
    build_s58_gdi_simulink_model();
elseif ~bdIsLoaded(model)
    load_system(modelFile);
end
inputBlocks = replaceVectorInputWithScalars(model);
ensurePressureConversions(model);

dash = model + "/Operator Dashboard";
if getSimulinkBlockHandle(dash) ~= -1
    delete_block(dash);
end
add_block("simulink/Ports & Subsystems/Subsystem", dash, ...
    "Position", [330 470 520 560], "BackgroundColor", "cyan");
Simulink.SubSystem.deleteContents(dash);

detail = model + "/Injector Detail Dashboard";
if getSimulinkBlockHandle(detail) ~= -1
    delete_block(detail);
end
add_block("simulink/Ports & Subsystems/Subsystem", detail, ...
    "Position", [550 470 750 560], "BackgroundColor", "orange");
Simulink.SubSystem.deleteContents(detail);

% Controls tune individual elements of the Live Vehicle Inputs vector.
controls = {
    "RPM",                 1,  600,  500, 8000;
    "Engine Load pct",     2,    0,   10,  120;
    "Boost Target psi",    3,    0,    5,   40;
    "Actual Boost psi",    4,    0,    5,   40;
    "Intake Air Temp C",   5,  -20,   20,  100;
    "Battery Voltage V",   6,    8,    1, 16.5;
    "Measured Lambda",     7,  0.7,  0.1,  1.2;
    "Rail Pressure psi",   8,  700,  500, 5000};

for k = 1:size(controls, 1)
    row = mod(k-1, 4);
    col = floor((k-1) / 4);
    x = 35 + col * 385;
    y = 45 + row * 92;
    block = dash + "/" + controls{k,1};
    add_block("simulink_hmi_blocks/Slider", block, ...
        "Position", [x y x+270 y+65], "ShowName", "on", ...
        "ShowInitialText", "off", "LabelPosition", "Hide");
    source = Simulink.HMI.ParamSourceInfo;
    source.BlockPath = Simulink.BlockPath(inputBlocks(k));
    source.ParamName = 'Value';
    set_param(block, "Binding", source, ...
        "Limits", [controls{k,3} -1 controls{k,5}]);
    addSignalDisplay(dash, controls{k,1}+" Readout", inputBlocks(k), 1, ...
        [x+285 y+8 x+360 y+57], "%.2f");
end

% Numeric operating-point indicators.
addSignalDisplay(dash, "Fuel Request", model + "/Fuel Mass and Lambda Scheduling", 1, [815 60 980 130], "%.2f mg");
addSignalDisplay(dash, "Lambda Target", model + "/Fuel Mass and Lambda Scheduling", 2, [1000 60 1165 130], "%.3f lambda");
addSignalDisplay(dash, "Pulse Width", model + "/Injection Event Controller", 2, [1185 60 1350 130], "%.3f ms");
addSignalDisplay(dash, "Coil Current", model + "/PT2000 and Injector Plant", 1, [1370 60 1535 130], "%.2f A");

% Gauges provide fast visual operating-state feedback.
addGauge(dash, "Engine Speed", model + "/RPM", 1, [825 165 1045 355], [0 1000 8000]);
addGauge(dash, "Actual Boost Gauge psi", model + "/Boost Actual Command", 1, [1070 165 1290 355], [0 5 40]);
addGauge(dash, "Rail Pressure Gauge psi", model + "/Rail Pressure Command", 1, [1315 165 1535 355], [500 500 5000]);

% Live scopes bind to actual executable model signals.
addScope(dash, "Live Injector Current", ...
    {signalSpec(model + "/PT2000 and Injector Plant", 1)}, ...
    [35 430 765 780], "0.02", -1, 14);
addScope(dash, "Live Boost Tracking psi", ...
    {signalSpec(model + "/Boost Target Command", 1), ...
     signalSpec(model + "/Boost Actual Command", 1)}, ...
    [805 430 1535 780], "5", 0, 40);

% The detail screen keeps dense engineering traces off the operator view.
addScope(detail, "Injector Current", ...
    {signalSpec(model + "/PT2000 and Injector Plant", 1)}, ...
    [40 50 720 390], "0.02", -1, 14);
addScope(detail, "Fuel Request and Delivery", ...
    {signalSpec(model + "/Fuel Mass and Lambda Scheduling", 1), ...
     signalSpec(model + "/PT2000 and Injector Plant", 2)}, ...
    [760 50 1440 390], "2", 0, 60);
addScope(detail, "Boost Target and Actual", ...
    {signalSpec(model + "/Boost Target Command", 1), ...
     signalSpec(model + "/Boost Actual Command", 1)}, ...
    [40 440 720 780], "5", 0, 40);
addScope(detail, "Lambda Target and Measured", ...
    {signalSpec(model + "/Fuel Mass and Lambda Scheduling", 2), ...
     signalSpec(model + "/Lambda_Measured", 1)}, ...
    [760 440 1440 780], "5", 0.65, 1.25);

set_param(model, "StopTime", "inf");
set_param(model, "PreLoadFcn", "initialize_s58_gdi_project();");
set_param(model, "BlockReduction", "off", ...
    "OptimizeBlockIOStorage", "off", "DefaultParameterBehavior", "Tunable");
streamDashboardSignals(model);
layoutTopLevel(model);
configureRunLogging(model, folder);
save_system(model, modelFile);
open_system(dash);
set_param(dash, "ZoomFactor", "FitSystem");
end

function addSignalDisplay(parent, name, source, port, position, format)
block = parent + "/" + name;
add_block("simulink_hmi_blocks/Display", block, ...
    "Position", position, "ShowName", "on", "ShowInitialText", "off", ...
    "Format", "Custom", "FormatString", format);
set_param(block, "Binding", signalSpec(source, port));
end

function addGauge(parent, name, source, port, position, limits)
block = parent + "/" + name;
add_block("simulink_hmi_blocks/Gauge", block, ...
    "Position", position, "ShowName", "on", "ShowInitialText", "off", "Limits", limits);
set_param(block, "Binding", signalSpec(source, port));
end

function addScope(parent, name, signals, position, timeSpan, yMin, yMax)
block = parent + "/" + name;
add_block("simulink_hmi_blocks/Dashboard Scope", block, ...
    "Position", position, "ShowName", "on", "ShowInitialText", "off", "Binding", signals, ...
    "TimeSpan", timeSpan, "UpdateMode", "Scroll", "LegendPosition", "Top");
set_param(block, "UserData", struct("SuggestedYLimits", [yMin yMax]));
end

function spec = signalSpec(source, port)
spec = Simulink.HMI.SignalSpecification;
spec.BlockPath = Simulink.BlockPath(source);
spec.OutputPortIndex = port;
end

function inputBlocks = replaceVectorInputWithScalars(model)
names = ["RPM Command","Load Command","Boost Target Command", ...
    "Boost Actual Command","IAT Command","Battery Command", ...
    "Lambda Command","Rail Pressure Command"];
values = [1200 20 0 0 30 13.5 1.0 1450];
inputBlocks = model + "/" + names;
mux = model + "/Vehicle Input Mux";
if getSimulinkBlockHandle(mux) ~= -1 && ...
        all(arrayfun(@(path) getSimulinkBlockHandle(path) ~= -1, inputBlocks))
    for k = 1:8, set_param(inputBlocks(k), "Value", string(values(k))); end
    decoderLines = get_param(model + "/Vehicle Signal Decode", "LineHandles");
    if decoderLines.Inport == -1
        add_line(model, "Vehicle Input Mux/1", "Vehicle Signal Decode/1");
    end
    return;
end

decoderLines = get_param(model + "/Vehicle Signal Decode", "LineHandles");
if decoderLines.Inport ~= -1, delete_line(decoderLines.Inport); end
old = model + "/Live Vehicle Inputs";
if getSimulinkBlockHandle(old) ~= -1
    handles = get_param(old, "LineHandles");
    if handles.Outport ~= -1, delete_line(handles.Outport); end
    delete_block(old);
end

if getSimulinkBlockHandle(mux) ~= -1, delete_block(mux); end
add_block("simulink/Signal Routing/Mux", mux, "Inputs", "8", ...
    "Position", [115 65 120 345]);
for k = 1:8
    inputBlocks(k) = model + "/" + names(k);
    if getSimulinkBlockHandle(inputBlocks(k)) ~= -1, delete_block(inputBlocks(k)); end
    add_block("simulink/Sources/Constant", inputBlocks(k), ...
        "Value", string(values(k)), "Position", [15 30+40*k 90 50+40*k]);
    add_line(model, names(k)+"/1", "Vehicle Input Mux/"+k);
end
add_line(model, "Vehicle Input Mux/1", "Vehicle Signal Decode/1");
end

function ensurePressureConversions(model)
addConversion(model, 3, "Boost psi to kPa", "6.894757293", "Boost_Target_kPa");
addConversion(model, 4, "Actual boost psi to kPa", "6.894757293", "Boost_Actual_kPa");
addConversion(model, 8, "Rail psi to bar", "0.0689475729", "Rail_Actual_bar");
end

function addConversion(model, demuxPort, gainName, gainValue, destinationName)
gain = model + "/" + gainName;
destination = model + "/" + destinationName;
destinationLines = get_param(destination, "LineHandles");
if destinationLines.Inport ~= -1, delete_line(destinationLines.Inport); end
if getSimulinkBlockHandle(gain) ~= -1, delete_block(gain); end
position = get_param(destination, "Position");
add_block("simulink/Math Operations/Gain", gain, "Gain", gainValue, ...
    "Position", position - [85 0 45 0]);
add_line(model, "Vehicle Signal Decode/"+demuxPort, gainName+"/1");
add_line(model, gainName+"/1", destinationName+"/1");
end

function streamDashboardSignals(model)
sources = ["RPM","Load_pct","Boost_Target_kPa","Boost_Actual_kPa", ...
    "Lambda_Measured","Rail_Actual_bar", ...
    "RPM Command","Load Command","Boost Target Command", ...
    "Boost Actual Command","IAT Command","Battery Command", ...
    "Lambda Command","Rail Pressure Command", ...
    "Fuel Mass and Lambda Scheduling","Injection Event Controller", ...
    "PT2000 and Injector Plant"];
ports = ones(1, numel(sources));
ports(end-1) = 2;
for k = 1:numel(sources)
    Simulink.sdi.markSignalForStreaming(model + "/" + sources(k), ports(k), "on");
end
end

function layoutTopLevel(model)
names = ["RPM Command","Load Command","Boost Target Command", ...
    "Boost Actual Command","IAT Command","Battery Command", ...
    "Lambda Command","Rail Pressure Command"];
for k = 1:8
    y = 55 + (k-1)*55;
    set_param(model+"/"+names(k), "Position", [20 y 135 y+28]);
end
set_param(model+"/Vehicle Input Mux", "Position", [175 45 180 490]);
set_param(model+"/Vehicle Signal Decode", "Position", [225 45 230 490]);
signalNames = ["RPM","Load_pct","Boost_Target_kPa","Boost_Actual_kPa", ...
    "IAT_C","Battery_V","Lambda_Measured","Rail_Actual_bar"];
for k = 1:8
    y = 55 + (k-1)*55;
    set_param(model+"/"+signalNames(k), "Position", [400 y 500 y+28]);
end
set_param(model+"/Boost psi to kPa", "Position", [285 160 365 188]);
set_param(model+"/Actual boost psi to kPa", "Position", [285 215 365 243]);
set_param(model+"/Rail psi to bar", "Position", [285 435 365 463]);
set_param(model+"/CAN Receive and Validation", "Position", [555 95 745 315]);
set_param(model+"/Fuel Mass and Lambda Scheduling", "Position", [805 115 1005 265]);
set_param(model+"/Injection Event Controller", "Position", [1070 85 1280 300]);
set_param(model+"/PT2000 and Injector Plant", "Position", [1350 100 1555 280]);
set_param(model+"/CAN Transmit Status", "Position", [1630 120 1810 265]);
set_param(model+"/Model Monitoring", "Position", [1350 340 1555 505]);
set_param(model+"/Operator Dashboard", "Position", [620 560 820 650]);
set_param(model+"/Injector Detail Dashboard", "Position", [880 560 1095 650]);
end

function configureRunLogging(model, folder)
logFolder = fullfile(folder, "logs");
if ~isfolder(logFolder), mkdir(logFolder); end
startCode = "S58_RUN_LOG = fullfile('" + replace(logFolder,"\","/") + ...
    "','latest-run.log'); diary(S58_RUN_LOG); fprintf('S58 simulation start %s\\n',datetime('now'));";
stopCode = "fprintf('S58 simulation stop %s\\n',datetime('now')); diary off; " + ...
    "try, Simulink.sdi.save(fullfile('" + replace(logFolder,"\","/") + ...
    "','latest-run.mldatx')); catch ME, warning('%s',ME.message); end";
set_param(model, "StartFcn", startCode, "StopFcn", stopCode);
end
