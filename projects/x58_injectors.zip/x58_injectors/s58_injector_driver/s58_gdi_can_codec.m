function frame = s58_gdi_can_codec(kind, values, cal)
%S58_GDI_CAN_CODEC Encode deterministic CAN-FD demonstrator frames.
arguments
    kind (1,1) string
    values struct
    cal struct = s58_gdi_calibration()
end

data = zeros(1, 16, "uint8");
switch kind
    case "engine-state"
        frame.id = cal.can.engineStateId;
        data(1:2) = u16le(values.rpm, 0.25);
        data(3:4) = u16le(values.loadPct, 0.01);
        data(5:6) = i16le(values.iatC, 0.1);
        data(7:8) = u16le(values.batteryV, 0.001);
    case "air-path"
        frame.id = cal.can.airPathId;
        data(1:2) = i16le(values.boostTargetKPa, 0.01);
        data(3:4) = i16le(values.boostActualKPa, 0.01);
        data(5:6) = u16le(values.measuredLambda, 0.0001);
        data(7:8) = u16le(values.railActualBar, 0.1);
    case "fuel-command"
        frame.id = cal.can.fuelCommandId;
        data(1:2) = u16le(values.fuelRequestMg, 0.001);
        data(3:4) = u16le(values.pulseWidthMs, 0.001);
        data(5:6) = u16le(values.railTargetBar, 0.1);
        data(7:8) = u16le(values.lambdaTarget, 0.0001);
    otherwise
        error("S58GDI:UnknownFrame", "Unknown frame kind: %s", kind);
end
data(15) = uint8(mod(round(values.counter), 256));
data(16) = crc8(data(1:15));
frame.name = kind;
frame.extended = false;
frame.dlc = 16;
frame.data = data;
frame.counter = double(data(15));
frame.crcValid = crc8(data(1:15)) == data(16);
end

function bytes = u16le(value, scale)
raw = uint16(min(max(round(value / scale), 0), 65535));
bytes = typecast(raw, "uint8");
end

function bytes = i16le(value, scale)
raw = int16(min(max(round(value / scale), -32768), 32767));
bytes = typecast(raw, "uint8");
end

function value = crc8(bytes)
value = uint8(255);
for byte = bytes
    value = bitxor(value, byte);
    for bit = 1:8
        if bitand(value, uint8(128))
            value = bitxor(bitshift(value, 1), uint8(29));
        else
            value = bitshift(value, 1);
        end
    end
end
end
