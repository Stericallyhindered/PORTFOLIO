function out = s58_gdi_operating_point(in, cal)
%S58_GDI_OPERATING_POINT Calculate one scheduled GDI event.
arguments
    in struct
    cal struct = s58_gdi_calibration()
end

mustHave = ["rpm","loadPct","boostTargetKPa","boostActualKPa", ...
    "iatC","batteryV","measuredLambda"];
for name = mustHave
    assert(isfield(in, name), "S58GDI:MissingInput", "Missing input %s", name);
end

rpm = min(max(in.rpm, cal.engine.rpmBp(1)), cal.engine.rpmBp(end));
loadPct = min(max(in.loadPct, cal.engine.loadBp(1)), cal.engine.loadBp(end));
ve = interp2(cal.engine.rpmBp, cal.engine.loadBp, cal.fuel.ve, rpm, loadPct);
lambdaTarget = interp2(cal.engine.rpmBp, cal.engine.loadBp, cal.fuel.lambda, rpm, loadPct);
railTargetBar = interp2(cal.engine.rpmBp, cal.engine.loadBp, cal.fuel.railBar, rpm, loadPct);

manifoldKPa = max(20, cal.engine.ambientKPa + in.boostActualKPa);
airDensity = manifoldKPa * 1000 / (cal.engine.gasConstant * (in.iatC + 273.15));
cylinderVolumeM3 = cal.engine.displacementL / 1000 / cal.engine.cylinders;
airMg = airDensity * cylinderVolumeM3 * ve * 1e6;
fuelRequestMg = airMg / (cal.engine.stoichAfr * lambdaTarget);

if isfield(in, "railActualBar")
    railActualBar = in.railActualBar;
else
    railActualBar = railTargetBar;
end
flowMgPerMs = cal.injector.flowMgPerMsAt200Bar * ...
    sqrt(max(railActualBar, 1) / cal.injector.ratedPressureBar);
deadtimeMs = interp1(cal.injector.deadtimeBattV, cal.injector.deadtimeMs, ...
    in.batteryV, "linear", "extrap");
pulseWidthMs = fuelRequestMg / flowMgPerMs + deadtimeMs;
cycleMs = 120000 / rpm;
windowMs = cycleMs * cal.injector.windowDeg / 720;

out.rpm = rpm;
out.loadPct = loadPct;
out.ve = ve;
out.manifoldKPa = manifoldKPa;
out.airMgPerCylinder = airMg;
out.lambdaTarget = lambdaTarget;
out.lambdaError = in.measuredLambda - lambdaTarget;
out.railTargetBar = railTargetBar;
out.railActualBar = railActualBar;
out.fuelRequestMg = fuelRequestMg;
out.flowMgPerMs = flowMgPerMs;
out.deadtimeMs = deadtimeMs;
out.pulseWidthMs = pulseWidthMs;
out.windowMs = windowMs;
out.windowUsagePct = 100 * pulseWidthMs / windowMs;
out.fuelFlowGps = fuelRequestMg * cal.engine.cylinders * rpm / 120 / 1000;
out.boostErrorKPa = in.boostTargetKPa - in.boostActualKPa;
out.flags.pulseBelowLinear = pulseWidthMs < cal.injector.minLinearPulseMs;
out.flags.windowExceeded = pulseWidthMs > windowMs;
out.flags.railTracking = abs(railActualBar - railTargetBar) <= 25;
out.flags.inputClamped = rpm ~= in.rpm || loadPct ~= in.loadPct;
end
