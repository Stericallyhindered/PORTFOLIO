function open_wiring_diagram()
%OPEN_WIRING_DIAGRAM Draw conceptual PT2000 injector-driver board wiring.
%
% This is an architecture/wiring concept, not a released schematic. Pin names,
% protection values, MOSFET part numbers, and PT2000 register details must be
% checked against the exact datasheets and measured injector data before hardware.

fig = figure( ...
    "Name", "PT2000 Injector Driver Board Wiring Concept", ...
    "Color", [0.985 0.985 0.975], ...
    "Units", "normalized", ...
    "Position", [0.06 0.06 0.88 0.82]);

ax = axes(fig, "Position", [0 0 1 1]);
axis(ax, "off");
hold(ax, "on");

text(ax, 0.5, 0.965, "PT2000-Based S58 Injector Driver Board: One Channel Wiring Concept", ...
    "HorizontalAlignment", "center", "FontWeight", "bold", "FontSize", 16);
text(ax, 0.5, 0.935, "Repeat the power-stage channel six times; share battery input, protected ground strategy, boost rail, SPI/CAN/control, and diagnostics.", ...
    "HorizontalAlignment", "center", "FontSize", 10.5, "Color", [0.25 0.25 0.25]);

% External connectors.
drawBox(ax, [0.035 0.66 0.15 0.18], "Vehicle / ECU", ...
    ["VBAT fused"; "IGN/enable"; "SPI or MCU I/O"; "CAN / sync"; "logic ground"], [0.88 0.93 1.00]);
drawBox(ax, [0.79 0.55 0.17 0.18], "Injector Connector", ...
    ["Pin 1: INJ_A"; "Pin 2: INJ_B"; "twisted pair"; "breakout for scope"], [1.00 0.94 0.82]);

% Board functional blocks.
drawBox(ax, [0.25 0.72 0.16 0.13], "Input Protection", ...
    ["fuse / TVS"; "reverse protect"; "bulk capacitance"], [0.93 0.96 1.00]);
drawBox(ax, [0.48 0.72 0.16 0.13], "Boost Supply", ...
    ["65 V target"; "boost cap bank"; "UV/OV feedback"], [1.00 0.97 0.86]);
drawBox(ax, [0.25 0.47 0.18 0.18], "PT2000 / Driver IC", ...
    ["SPI config"; "peak/hold control"; "diagnostics"; "gate drive outputs"; "ADC/current monitor"], [0.88 1.00 0.90]);
drawBox(ax, [0.50 0.47 0.20 0.18], "Power Stage CH1", ...
    ["high-side switch"; "low-side switch"; "sense resistor"; "clamp / recirc path"; "gate resistors"], [0.94 1.00 0.92]);
drawBox(ax, [0.25 0.20 0.18 0.14], "MCU / Logic", ...
    ["cylinder schedule"; "SPI to PT2000"; "fault handling"; "CAN logging"], [0.93 0.92 1.00]);
drawBox(ax, [0.50 0.20 0.20 0.14], "Measurement Header", ...
    ["Vdiff test pads"; "sense voltage"; "boost rail"; "logic trigger"], [0.96 0.90 1.00]);

% Nets and arrows.
wire(ax, [0.185 0.765], [0.25 0.785], "VBAT");
wire(ax, [0.41 0.785], [0.48 0.785], "protected VBAT");
wire(ax, [0.56 0.72], [0.58 0.65], "+65 V boost rail");
wire(ax, [0.43 0.56], [0.50 0.56], "gate/control");
wire(ax, [0.35 0.47], [0.35 0.34], "SPI / faults");
wire(ax, [0.43 0.27], [0.50 0.27], "logged signals");

% Injector two-lead path.
wire(ax, [0.70 0.60], [0.79 0.66], "INJ_A");
wire(ax, [0.70 0.52], [0.79 0.61], "INJ_B");
drawCoil(ax, [0.805 0.39 0.14 0.08]);
text(ax, 0.875, 0.365, "injector coil", "HorizontalAlignment", "center", "FontSize", 9);
wire(ax, [0.86 0.55], [0.835 0.47], "");
wire(ax, [0.89 0.55], [0.915 0.47], "");

% Grounding and sensing.
plot(ax, [0.50 0.70], [0.43 0.43], "Color", [0.12 0.12 0.12], "LineWidth", 1.8);
text(ax, 0.60, 0.405, "power ground return through sense / star point", ...
    "HorizontalAlignment", "center", "FontSize", 8.5, "Color", [0.25 0.25 0.25]);
wire(ax, [0.60 0.47], [0.60 0.34], "sense voltage");

% Scope callouts.
drawScope(ax, [0.06 0.20 0.13 0.14]);
wire(ax, [0.19 0.29], [0.50 0.29], "scope B: current/sense");
wire(ax, [0.19 0.25], [0.79 0.63], "scope A: Vdiff across injector");
wire(ax, [0.19 0.21], [0.25 0.25], "scope C/D: sync/CAN/boost");

% Safety notes.
drawBox(ax, [0.74 0.20 0.20 0.15], "Bench Bring-Up", ...
    ["current-limited supply"; "dummy RL load first"; "isolated differential probe"; "thermal camera / scope"; "fused injector harness"], [1.00 0.91 0.91]);

text(ax, 0.5, 0.065, "Concept only: verify PT2000 pinout, gate-drive topology, clamp energy, sense scaling, layout creepage, fuse sizing, and injector ratings before energizing hardware.", ...
    "HorizontalAlignment", "center", "FontWeight", "bold", "FontSize", 10, "Color", [0.55 0.10 0.10]);

hold(ax, "off");
end

function drawBox(ax, pos, heading, lines, color)
rectangle(ax, "Position", pos, "Curvature", 0.035, ...
    "FaceColor", color, "EdgeColor", [0.22 0.22 0.22], "LineWidth", 1.1);
text(ax, pos(1) + pos(3)/2, pos(2) + pos(4) - 0.024, heading, ...
    "HorizontalAlignment", "center", "VerticalAlignment", "top", ...
    "FontWeight", "bold", "FontSize", 10.5, "Color", [0.07 0.07 0.07]);
text(ax, pos(1) + pos(3)/2, pos(2) + pos(4) - 0.052, strjoin(cellstr(lines), newline), ...
    "HorizontalAlignment", "center", "VerticalAlignment", "top", ...
    "FontSize", 8.8, "Color", [0.18 0.18 0.18]);
end

function wire(ax, p1, p2, label)
annotation(ax.Parent, "arrow", [p1(1) p2(1)], [p1(2) p2(2)], ...
    "LineWidth", 1.35, "Color", [0.12 0.12 0.12]);
if strlength(label) > 0
    text(ax, mean([p1(1) p2(1)]), mean([p1(2) p2(2)]) + 0.018, label, ...
        "HorizontalAlignment", "center", "FontSize", 8.5, ...
        "BackgroundColor", [0.985 0.985 0.975], "Margin", 1);
end
end

function drawCoil(ax, pos)
x0 = pos(1);
y0 = pos(2);
w = pos(3);
h = pos(4);
t = linspace(0, 6*pi, 240);
x = x0 + w * (t / max(t));
y = y0 + h/2 + h*0.35*sin(t);
plot(ax, x, y, "Color", [0.12 0.12 0.12], "LineWidth", 1.5);
plot(ax, [x0 - 0.025 x0], [y0 + h/2 y0 + h/2], "Color", [0.12 0.12 0.12], "LineWidth", 1.5);
plot(ax, [x0 + w x0 + w + 0.025], [y0 + h/2 y0 + h/2], "Color", [0.12 0.12 0.12], "LineWidth", 1.5);
end

function drawScope(ax, pos)
rectangle(ax, "Position", pos, "Curvature", 0.04, ...
    "FaceColor", [0.90 0.96 1.00], "EdgeColor", [0.22 0.22 0.22], "LineWidth", 1.1);
text(ax, pos(1) + pos(3)/2, pos(2) + pos(4) - 0.026, "PicoScope", ...
    "HorizontalAlignment", "center", "FontWeight", "bold", "FontSize", 10);
text(ax, pos(1) + pos(3)/2, pos(2) + pos(4) - 0.058, "A Vdiff" + newline + "B current" + newline + "C sync" + newline + "D CAN/boost", ...
    "HorizontalAlignment", "center", "VerticalAlignment", "top", "FontSize", 8.6);
end
