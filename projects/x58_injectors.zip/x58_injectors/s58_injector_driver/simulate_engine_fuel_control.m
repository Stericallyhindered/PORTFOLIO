function result = simulate_engine_fuel_control(cfg)
%SIMULATE_ENGINE_FUEL_CONTROL Estimate fuel command from engine operating point.
%
% This is a presentation and architecture model. It is not an ECU calibration.
% Replace placeholder VE, injector flow, and enrichment maps with measured data.

arguments
    cfg struct = default_engine_fuel_config()
end

rpm = cfg.engine.rpm;
load_pct = cfg.engine.load_pct;
boost_target_kpa = cfg.engine.boost_target_kpa;
boost_actual_kpa = cfg.engine.boost_actual_kpa;
iat_c = cfg.engine.iat_c;
lambda_base = cfg.fuel.lambda_base;
fuel_pressure_bar = cfg.fuel.pressure_bar;

engine_l = cfg.engine.displacement_l;
cylinders = cfg.engine.cylinders;
stoich_afr = cfg.fuel.stoich_afr;
ve_base = cfg.engine.ve_base;
injector_flow_cc_min = cfg.injector.flow_cc_min;
injector_deadtime_ms = cfg.injector.deadtime_ms;
injectors_per_cyl = cfg.injector.injectors_per_cyl;

ambient_kpa = cfg.engine.ambient_kpa;
manifold_kpa = max(25, ambient_kpa + boost_actual_kpa);
target_manifold_kpa = max(25, ambient_kpa + boost_target_kpa);
boost_error_kpa = boost_target_kpa - boost_actual_kpa;

load_factor = max(0.05, min(1.35, load_pct / 100));
rpm_factor = 0.88 + 0.12 * exp(-((rpm - 5200) / 2600)^2);
boost_factor = 0.82 + 0.18 * min(1.8, manifold_kpa / ambient_kpa);
ve = min(1.35, ve_base * load_factor * rpm_factor * boost_factor);

temp_k = iat_c + 273.15;
air_density_kg_m3 = (manifold_kpa * 1000) / (cfg.engine.r_air * temp_k);
disp_per_cycle_m3 = engine_l / 1000 / 2;
air_mass_per_cycle_kg = air_density_kg_m3 * disp_per_cycle_m3 * ve;
air_mass_per_cyl_mg = air_mass_per_cycle_kg * 1e6 / cylinders;

boost_ratio = target_manifold_kpa / ambient_kpa;
boost_lambda_trim = max(0, boost_ratio - 1) * cfg.fuel.lambda_enrich_per_boost_ratio;
load_lambda_trim = max(0, load_pct - 70) / 30 * cfg.fuel.lambda_enrich_at_high_load;
target_lambda = max(cfg.fuel.lambda_min, lambda_base - boost_lambda_trim - load_lambda_trim);

fuel_mass_per_cyl_mg = air_mass_per_cyl_mg / (stoich_afr * target_lambda);

fuel_density_g_cc = cfg.fuel.density_g_cc;
flow_pressure_factor = sqrt(max(0.2, fuel_pressure_bar / cfg.injector.rated_pressure_bar));
injector_flow_g_s = injector_flow_cc_min * fuel_density_g_cc / 60 * flow_pressure_factor;
fuel_mass_per_injector_mg = fuel_mass_per_cyl_mg / injectors_per_cyl;
base_pw_ms = fuel_mass_per_injector_mg / (injector_flow_g_s * 1000) * 1000;
commanded_pw_ms = base_pw_ms + injector_deadtime_ms;

cycle_time_ms = 120000 / rpm;
available_window_ms = cycle_time_ms * cfg.injector.injection_window_deg / 720;
duty_pct = commanded_pw_ms / cycle_time_ms * 100;
window_usage_pct = commanded_pw_ms / available_window_ms * 100;
headroom_pct = max(0, 100 - window_usage_pct);

fuel_flow_g_s = fuel_mass_per_cyl_mg * cylinders * rpm / 120 / 1000;
air_flow_g_s = air_mass_per_cyl_mg * cylinders * rpm / 120 / 1000;
lambda_error = cfg.fuel.lambda_measured - target_lambda;

pt = init_s58_injector_params();
pt.control.t_injection_s = commanded_pw_ms / 1000;
pt.control.t_total_s = max(3.2e-3, pt.control.t_injection_s + 1.0e-3);
pt.driver.v_batt = cfg.electrical.v_batt;
pt.driver.v_hold = cfg.electrical.v_batt;
pt.driver.v_boost = cfg.electrical.v_boost;
pt.control.i_peak_a = cfg.electrical.i_peak_a;
pt.control.i_hold_low_a = cfg.electrical.i_hold_low_a;
pt.control.i_hold_high_a = cfg.electrical.i_hold_high_a;
injectorTrace = simulate_single_injector(pt);

result.inputs = cfg;
result.manifold_kpa = manifold_kpa;
result.target_manifold_kpa = target_manifold_kpa;
result.boost_error_kpa = boost_error_kpa;
result.ve = ve;
result.air_mass_per_cyl_mg = air_mass_per_cyl_mg;
result.fuel_mass_per_cyl_mg = fuel_mass_per_cyl_mg;
result.fuel_mass_per_injector_mg = fuel_mass_per_injector_mg;
result.commanded_pw_ms = commanded_pw_ms;
result.base_pw_ms = base_pw_ms;
result.deadtime_ms = injector_deadtime_ms;
result.target_lambda = target_lambda;
result.lambda_error = lambda_error;
result.cycle_time_ms = cycle_time_ms;
result.available_window_ms = available_window_ms;
result.duty_pct = duty_pct;
result.window_usage_pct = window_usage_pct;
result.headroom_pct = headroom_pct;
result.air_flow_g_s = air_flow_g_s;
result.fuel_flow_g_s = fuel_flow_g_s;
result.injector_trace = injectorTrace;
end

function cfg = default_engine_fuel_config()
cfg.engine.rpm = 4500;
cfg.engine.load_pct = 78;
cfg.engine.boost_target_kpa = 150;
cfg.engine.boost_actual_kpa = 135;
cfg.engine.iat_c = 35;
cfg.engine.ambient_kpa = 101.3;
cfg.engine.displacement_l = 3.0;
cfg.engine.cylinders = 6;
cfg.engine.ve_base = 0.98;
cfg.engine.r_air = 287.05;

cfg.fuel.lambda_base = 1.00;
cfg.fuel.lambda_min = 0.78;
cfg.fuel.lambda_measured = 0.92;
cfg.fuel.lambda_enrich_per_boost_ratio = 0.055;
cfg.fuel.lambda_enrich_at_high_load = 0.055;
cfg.fuel.stoich_afr = 14.1;
cfg.fuel.pressure_bar = 250;
cfg.fuel.density_g_cc = 0.745;

cfg.injector.flow_cc_min = 980;
cfg.injector.rated_pressure_bar = 200;
cfg.injector.deadtime_ms = 0.32;
cfg.injector.injectors_per_cyl = 1;
cfg.injector.injection_window_deg = 260;

cfg.electrical.v_batt = 13.5;
cfg.electrical.v_boost = 65;
cfg.electrical.i_peak_a = 11.0;
cfg.electrical.i_hold_low_a = 3.4;
cfg.electrical.i_hold_high_a = 4.2;
end
