function result = run_s58_gdi_scenario(durationS, sampleTimeS, cal)
%RUN_S58_GDI_SCENARIO Simulate a repeatable load/boost/RPM drive event.
arguments
    durationS (1,1) double {mustBePositive} = 8
    sampleTimeS (1,1) double {mustBePositive} = 0.01
    cal struct = s58_gdi_calibration()
end
t = (0:sampleTimeS:durationS).';
n = numel(t);
rpm = 1100 + 5600 * smoothstep(t / durationS);
loadPct = 18 + 92 * smoothstep((t - 0.8) / (durationS - 1.6));
boostTarget = max(0, 190 * smoothstep((t - 1.3) / 3.2));
boostActual = filter(sampleTimeS / (0.28 + sampleTimeS), ...
    [1 -(1 - sampleTimeS / (0.28 + sampleTimeS))], boostTarget);

names = ["fuelRequestMg","pulseWidthMs","lambdaTarget","railTargetBar", ...
    "windowUsagePct","fuelFlowGps"];
for name = names, data.(name) = zeros(n, 1); end
frames(n,1) = struct("id", 0, "name", "", "extended", false, ...
    "dlc", 16, "data", zeros(1,16,"uint8"), "counter", 0, "crcValid", false);
for k = 1:n
    in = struct("rpm", rpm(k), "loadPct", loadPct(k), ...
        "boostTargetKPa", boostTarget(k), "boostActualKPa", boostActual(k), ...
        "iatC", 35 + 12 * t(k) / durationS, "batteryV", 13.5, ...
        "measuredLambda", 1.0, "railActualBar", NaN);
    provisional = s58_gdi_operating_point(rmfield(in,"railActualBar"), cal);
    in.railActualBar = provisional.railTargetBar - 5 * sin(2*pi*0.7*t(k));
    point = s58_gdi_operating_point(in, cal);
    for name = names, data.(name)(k) = point.(name); end
    point.counter = k - 1;
    frames(k) = s58_gdi_can_codec("fuel-command", point, cal);
end
result.timeS = t;
result.rpm = rpm;
result.loadPct = loadPct;
result.boostTargetKPa = boostTarget;
result.boostActualKPa = boostActual;
for name = names, result.(name) = data.(name); end
result.frames = frames;
result.calibration = cal;
end

function y = smoothstep(x)
x = min(max(x, 0), 1);
y = x.^2 .* (3 - 2*x);
end
