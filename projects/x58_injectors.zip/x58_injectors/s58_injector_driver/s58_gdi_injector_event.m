function event = s58_gdi_injector_event(command, cal)
%S58_GDI_INJECTOR_EVENT Coupled coil, armature-lift proxy, and fuel-flow model.
arguments
    command struct
    cal struct = s58_gdi_calibration()
end

dt = cal.driver.sampleTimeS;
tEnd = max(3e-3, command.pulseWidthMs * 1e-3 + 1e-3);
t = 0:dt:tEnd;
n = numel(t);
current = zeros(1, n);
voltage = zeros(1, n);
lift = zeros(1, n);
flow = zeros(1, n);
phase = zeros(1, n, "uint8");
rCoil = cal.injector.coilR25Ohm * ...
    (1 + cal.injector.coilTempCoeff * (command.coilTempC - 25));
rTotal = rCoil + cal.driver.switchROhm;
peakLatched = false;
armatureLatched = false;

for k = 2:n
    energized = t(k) <= command.pulseWidthMs * 1e-3;
    if energized && ~peakLatched
        voltage(k) = cal.driver.boostV;
        phase(k) = 1; % BOOST/PEAK
        peakLatched = current(k-1) >= cal.driver.peakCurrentA || ...
            t(k) >= cal.driver.peakTimeoutS;
    elseif energized
        if current(k-1) <= cal.driver.holdLowA
            voltage(k) = command.batteryV;
            phase(k) = 2; % HOLD ON
        elseif current(k-1) >= cal.driver.holdHighA
            voltage(k) = 0;
            phase(k) = 3; % HOLD RECIRCULATE
        else
            voltage(k) = voltage(k-1);
            phase(k) = phase(k-1);
        end
    elseif current(k-1) > 0.01
        voltage(k) = cal.driver.clampV;
        phase(k) = 4; % FLYBACK
    end

    current(k) = max(0, current(k-1) + ...
        (voltage(k) - current(k-1) * rTotal) / cal.injector.coilLH * dt);
    if energized && current(k) >= cal.injector.openCurrentA
        armatureLatched = true;
    elseif ~energized
        armatureLatched = false;
    end
    targetLift = double(armatureLatched);
    if targetLift > lift(k-1)
        tau = cal.injector.openTauS;
    else
        tau = cal.injector.closeTauS;
    end
    lift(k) = min(max(lift(k-1) + (targetLift - lift(k-1)) / tau * dt, 0), 1);
    flow(k) = lift(k) * command.flowMgPerMs * 1000;
end

event.tS = t;
event.currentA = current;
event.voltageV = voltage;
event.normalizedLift = lift;
event.flowMgPerS = flow;
event.phase = phase;
event.deliveredMg = trapz(t, flow);
event.peakCurrentA = max(current);
event.openTimeUs = firstCrossing(t, lift, 0.5) * 1e6;
event.closeTimeUs = lastCrossing(t, lift, 0.5) * 1e6;
event.coilEnergyJ = trapz(t, current.^2 * rCoil);
event.faults.peakTimeout = max(current(t <= cal.driver.peakTimeoutS)) < ...
    0.95 * cal.driver.peakCurrentA;
event.faults.openNotDetected = max(lift) < 0.5;
event.faults.massError = abs(event.deliveredMg - command.fuelRequestMg) > ...
    max(0.5, 0.08 * command.fuelRequestMg);
end

function value = firstCrossing(t, signal, threshold)
idx = find(signal >= threshold, 1, "first");
if isempty(idx), value = NaN; else, value = t(idx); end
end

function value = lastCrossing(t, signal, threshold)
idx = find(signal >= threshold, 1, "last");
if isempty(idx), value = NaN; else, value = t(idx); end
end
