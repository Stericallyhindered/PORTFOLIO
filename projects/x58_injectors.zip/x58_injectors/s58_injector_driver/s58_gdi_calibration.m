function cal = s58_gdi_calibration()
%S58_GDI_CALIBRATION Versioned demonstrator calibration and model metadata.
% Values marked ESTIMATE must be replaced by measurements before hardware use.

cal.meta.name = "S58 GDI architecture demonstrator";
cal.meta.revision = "0.2.0";
cal.meta.intendedUse = "Simulation and bench architecture validation only";
cal.meta.status = "ESTIMATE - not a production engine calibration";

cal.engine.displacementL = 3.0;
cal.engine.cylinders = 6;
cal.engine.stoichAfr = 14.1;
cal.engine.gasConstant = 287.05;
cal.engine.ambientKPa = 101.325;
cal.engine.rpmBp = [800 1500 2500 3500 4500 5500 6500 7500];
cal.engine.loadBp = [10 25 40 55 70 85 100 120];

% Volumetric efficiency and lambda targets: architecture estimates.
cal.fuel.ve = [
 .48 .50 .51 .51 .50 .48 .45 .42
 .62 .67 .70 .71 .70 .68 .64 .59
 .72 .79 .84 .87 .88 .86 .82 .76
 .78 .87 .94 .99 1.02 1.01 .97 .90
 .82 .91 1.00 1.06 1.10 1.10 1.06 .98
 .84 .94 1.04 1.11 1.16 1.17 1.13 1.05
 .85 .96 1.07 1.15 1.20 1.21 1.17 1.08
 .85 .97 1.09 1.18 1.23 1.24 1.19 1.10];
cal.fuel.lambda = [
 1.00 1.00 1.00 1.00 1.00 1.00 1.00 1.00
 1.00 1.00 1.00 1.00 1.00 1.00 1.00 1.00
 1.00 1.00 1.00 1.00 .99 .98 .98 .98
 .98 .98 .97 .96 .94 .92 .91 .91
 .94 .93 .92 .90 .88 .86 .85 .85
 .90 .89 .87 .85 .83 .82 .82 .83
 .87 .86 .84 .82 .80 .80 .81 .82
 .85 .84 .82 .80 .79 .80 .81 .83];
cal.fuel.railBar = [
 70 75 85 95 105 115 125 135
 75 85 100 120 140 160 175 185
 85 100 125 150 180 210 235 250
 95 120 150 185 220 250 275 290
 105 135 170 210 250 280 300 310
 115 145 185 225 265 295 315 325
 120 155 195 235 275 305 325 335
 125 160 200 240 280 310 330 340];

cal.injector.flowMgPerMsAt200Bar = 15.0; % ESTIMATE
cal.injector.ratedPressureBar = 200;
cal.injector.deadtimeBattV = [9 10 11 12 13.5 15 16];
cal.injector.deadtimeMs = [.62 .52 .45 .39 .32 .28 .26];
cal.injector.minLinearPulseMs = 0.45;
cal.injector.windowDeg = 260;
cal.injector.coilR25Ohm = 1.25;           % ESTIMATE
cal.injector.coilTempCoeff = 0.00393;
cal.injector.coilLH = 280e-6;             % ESTIMATE
cal.injector.openCurrentA = 5.5;           % ESTIMATE
cal.injector.openTauS = 80e-6;             % ESTIMATE
cal.injector.closeTauS = 65e-6;            % ESTIMATE

cal.driver.boostV = 65;
cal.driver.clampV = -55;
cal.driver.peakCurrentA = 11;
cal.driver.peakTimeoutS = 0.55e-3;
cal.driver.holdLowA = 3.4;
cal.driver.holdHighA = 4.2;
cal.driver.switchROhm = 0.08;
cal.driver.sampleTimeS = 0.5e-6;

cal.can.engineStateId = hex2dec('180');
cal.can.airPathId = hex2dec('181');
cal.can.fuelCommandId = hex2dec('280');
cal.can.driverStatusId = hex2dec('380');
cal.can.commandPeriodMs = 5;
cal.can.timeoutMs = 15;
end
